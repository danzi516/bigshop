<script>
const baseURL = 'http://127.0.0.1:7001'
const userId = ''
const orgId = ''

export default {
  baseURL,
  userId,
  orgId,
  setUserId(userId){
	this.userId = userId;
  },
  setOrgId(orgId){
	this.orgId = orgId;
  }
}
</script>