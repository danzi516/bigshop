<template>
    <div class="vue-sku">
        <!-- 规格设置 -->
        <el-card class="box-card">
            <!-- <div slot="header" class="clearfix">
                        <span>产品规格设置</span>
            </div>-->
            <section>
                <div v-for="(item, index) in specification" :key="index" class="spec-line">
                    <div>
                        <span v-if="!cacheSpecification[index].status">{{ item.name }}</span>
                        <el-input
                            size="small"
                            style="width:200px;"
                            v-if="cacheSpecification[index].status"
                            v-model="cacheSpecification[index].name"
                            placeholder="输入产品规格"
                            @keyup.native.enter="saveSpec(index)"
                        >
                            <el-button
                                slot="append"
                                icon="el-icon-check"
                                type="primary"
                                @click="saveSpec(index)"
                            ></el-button>
                        </el-input>
                        <i
                            class="icon el-icon-edit"
                            v-if="!cacheSpecification[index].status"
                            @click="updateSpec(index)"
                        ></i>
                    </div>
                    <div>
                        <el-tag
                            v-for="(tag, j) in item.ProductAttrSaleValues"
                            :key="j"
                            closable
                            @close="delSpecTag(index, j)"
                        >{{ tag.name }}</el-tag>
                        <el-input
                            size="small"
                            style="width:200px;"
                            v-model="addValues[index]"
                            placeholder="多个产品属性以空格隔开"
                            @keyup.native.enter="addSpecTag(index)"
                        >
                            <el-button
                                slot="append"
                                icon="el-icon-check"
                                type="primary"
                                @click="addSpecTag(index)"
                            ></el-button>
                        </el-input>
                    </div>
                    <i class="icon el-icon-circle-close spec-deleted" @click="delSpec(index)"></i>
                    <el-divider></el-divider>
                </div>
                <div class="add-spec">
                    <el-button
                        size="small"
                        type="primary"
                        :disabled="specification.length >= 5"
                        @click="addSpec"
                    >添加规格项目</el-button>
                </div>
            </section>
        </el-card>

        <el-card>
            <!-- <div slot="header" class="clearfix">
                        <span>规格表格</span>
            </div>-->
            <table class="el-table" cellspacing="0" cellpadding="0">
                <thead>
                    <tr>
                        <th v-for="(item, index) in specificationReal" :key="index">{{item.name}}</th>
                        <th style="width: 160px;">商品编码</th>
                        <th style="width: 70px;">库存</th>
                        <th style="width: 100px;">销售价（元）</th>
                        <th>是否启用</th>
                    </tr>
                </thead>
                <tbody
                    v-if="specificationReal[0] && specificationReal[0].ProductAttrSaleValues.length"
                >
                    <tr :key="index" v-for="(item, index) in skuAttrList">
                        <template v-for="(n, specIndex) in item.attrList">
                            <td :key="specIndex" :rowspan="n.length">{{n.value}}</td>
                        </template>
                        <td>
                            <el-input
                                size="small"
                                type="text"
                                :disabled="item.state==='1'?false:true"
                                v-model="item.childProductNo"
                                placeholder="输入商品编号"
                            ></el-input>
                        </td>

                        <td>
                            <el-input
                                size="small"
                                type="text"
                                v-model.number="item.stock"
                                placeholder="输入库存"
                                :disabled="item.state==='1'?false:true"
                            ></el-input>
                        </td>
                        <td>
                            <el-input
                                size="small"
                                type="text"
                                v-model.number="item.price"
                                placeholder="输入销售价"
                                :disabled="item.state==='1'?false:true"
                            ></el-input>
                        </td>
                        <td>
                            <el-switch v-model="item.state" active-value="1" inactive-value="0"></el-switch>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="8" class="wh-foot">
                            <span class="label">批量设置：</span>
                            <template v-if="isSetListShow">
                                <el-button @click="openBatch('stock')" size="mini">库存</el-button>
                                <el-button @click="openBatch('price')" size="mini">销售价</el-button>
                            </template>
                            <template v-else>
                                <el-input
                                    size="mini"
                                    style="width:200px;"
                                    v-model.number="batchValue"
                                    placeholder="输入要设置的数量"
                                ></el-input>
                                <el-button type="primary" size="mini" @click="setBatch">
                                    <i class="set-btn blue el-icon-check"></i>
                                </el-button>
                                <el-button type="danger" size="mini" @click="cancelBatch">
                                    <i class="set-btn blue el-icon-close"></i>
                                </el-button>
                            </template>
                        </td>
                    </tr>
                </tbody>
            </table>
        </el-card>
        <span slot="footer" class="dialog-footer">
            <el-button @click="editVisible = false">取 消</el-button>
            <el-button type="primary" @click="saveEdit">确 定</el-button>
        </span>
    </div>
</template>

<script>
import { getHttp, postHttp } from '@/api/index';
export default {
    name: 'app',
    props: {
        attrDate: Array,
        cacheSpecifica: Array
    },
    data() {
        return {
            specificationStatus: false, // 显示规格列表
            // 规格
            specification: [],
            specificationReal: [],
            // 子规格
            childProductArray: [],
            // 用来存储要添加的规格属性
            addValues: [],
            // 默认商品编号
            defaultProductNo: 'PRODUCTNO_',
            // 批量设置相关
            isSetListShow: true,
            batchValue: '', // 批量设置所绑定的值
            currentType: '', // 要批量设置的类型
            cacheSpecification: [], // 缓存规格名称
            skuAttrList: []
        };
    },

    computed: {
        // 所有sku的id
        stockSpecArr() {
            return this.childProductArray.map(item => item.childProductSpec);
        }
    },
    created() {
        //this.createData();
    },
    methods: {
        // 创建模拟数据
        createData() {
            // this.specification = [
            //     {
            //         name: '保存',
            //         ProductAttrSaleValues: [{ name: '冷冻' }, { name: '常温' }]
            //     },
            //     {
            //         name: '年龄' ,
            //         ProductAttrSaleValues: [{ name: '18' }, { name: '20' }]
            //     }
            // ];
            // this.cacheSpecification = [
            //     {
            //         status: false,
            //         name: '保存'
            //     },
            //     {
            //         status: false,
            //         name: '年龄'
            //     }
            // ];
            // let data = this.specification
            // data.forEach(item => {
            //     item.status = false
            // });
            // this.cacheSpecification = data

            this.specification = this.attrDate;
            this.cacheSpecification = this.cacheSpecifica;
            console.log(this.specification);
            console.log(this.cacheSpecification);
            this.skuProperties();
        },
        // 添加规格项目
        addSpec() {
            if (this.specification.length < 5) {
                this.cacheSpecification.push({
                    status: true,
                    name: ''
                });
                this.specification.push({
                    name: '',
                    ProductAttrSaleValues: []
                });
                console.log(this.specification);
                console.log(this.cacheSpecification);
            }
        },
        // 修改状态
        updateSpec(index) {
            this.cacheSpecification[index].status = true;
            this.cacheSpecification[index].name = this.specification[index].name;
        },
        // 保存规格名
        saveSpec(index) {
            console.log(this.cacheSpecification[index]);
            console.log(this.specification[index]);
            if (!this.cacheSpecification[index].name.trim()) {
                this.$message.error('名称不能为空，请注意修改');
                return;
            }
            // 保存需要验证名称是否重复
            if (this.verifyRepeat(index)) {
                // 如果有重复的，禁止修改
                this.$message.error('名称重复，请注意修改');
            } else {
                if (this.specification[index].name === this.cacheSpecification[index].name) {
                    this.cacheSpecification[index].status = false;
                    this.updateAttrSale(this.specification[index]);
                } else {
                    this.specification[index].name = this.cacheSpecification[index].name;
                    // this.$parent.addAttrSale({name:this.specification[index].name}); //调用父组件方法
                    this.addAttrSale(this.specification[index], index);

                    this.cacheSpecification[index].status = false;
                }
            }
        },
        // 删除规格项目
        delSpec(index) {
            this.delAttrSale(this.specification[index]);
            this.delSkuExt(this.specification[index]);
            this.specification.splice(index, 1);
            this.cacheSpecification.splice(index, 1);
            this.skuProperties();
        },
        verifyRepeat(index) {
            let flag = false;
            this.specification.forEach((value, j) => {
                // 检查除了当前选项以外的值是否和新的值想等，如果相等，则禁止修改
                if (index !== j) {
                    if (this.specification[j].name === this.cacheSpecification[index].name) {
                        flag = true;
                    }
                }
            });
            return flag;
        },
        // 添加规格属性
        addSpecTag(index) {
            let str = this.addValues[index] || '';
            if (!str.trim() || !this.cacheSpecification[index].name.trim()) {
                this.$message.error('名称不能为空，请注意修改');
                return;
            } // 判空
            str = str.trim();
            let arr = str.split(/\s+/); // 使用空格分割成数组
            arr = Array.from(new Set(arr)); // 去重
            let valueList = [];
            for (let i = 0; i < arr.length; i++) {
                let value = {};
                value.name = arr[i];
                valueList.push(value);
            }
            let newArr = this.specification[index].ProductAttrSaleValues.concat(valueList);

            this.$set(this.specification[index], 'ProductAttrSaleValues', newArr);

            this.clearAddValues(index);

            console.log(this.specification);

            this.specification[index].name = this.cacheSpecification[index].name;
            this.cacheSpecification[index].status = false;
            this.addAttrSaleValue(this.specification[index], valueList);
            this.delSkuExt(this.specification[index]);
            this.skuProperties();
        },

        // 删除规格属性
        delSpecTag(index, num) {
            this.delAttrSaleValue(this.specification[index].ProductAttrSaleValues[num]);
            this.delSkuExt(this.specification[index]);
            this.specification[index].ProductAttrSaleValues.splice(num, 1);
            this.skuProperties();
        },

        // 清空 addValues
        clearAddValues(index) {
            this.$set(this.addValues, index, '');
        },

        // 打开设置框
        openBatch(type) {
            this.currentType = type;
            this.isSetListShow = false;
        },

        // 批量设置
        setBatch() {
            if (typeof this.batchValue === 'string') {
                this.$message({
                    type: 'warning',
                    message: '请输入正确的值'
                });
                return;
            }
            this.skuAttrList.forEach(item => {
                if (item.state == '1' ? true : false) {
                    item[this.currentType] = this.batchValue;
                }
            });

            this.cancelBatch();
        },

        // 取消批量设置
        cancelBatch() {
            this.batchValue = '';
            this.currentType = '';
            this.isSetListShow = true;
        },
        saveEdit() {
            let param = {};
            param.skuAttrList = this.skuAttrList;
            postHttp('/productSkuExt/bulkCreate', param).then(res => {
                console.log(res);
            });
        },
        skuProperties() {
            if (this.specification) {
                console.log(this.specification);
                this.specificationReal = this.specification.filter(item => {
                    return item.name != null && item.ProductAttrSaleValues.length != 0;
                });
                console.log(this.specificationReal);

                let res = this.specificationReal.reduce(
                    (pre, cur) => {
                        let result = [];
                        pre.forEach(e1 => {
                            // e1 {}
                            //cur {"attrName":"肤色",ProductAttrSaleValues:["黑色","黄色"]}
                            //attrIndex    位置  索引值   0_0_0
                            e1.attrIndex = (e1.attrIndex || '') + '_'; // e1 = {attrIndex:'_'}
                            for (let i = 0; i < cur.ProductAttrSaleValues.length; i++) {
                                let e2 = cur.ProductAttrSaleValues[i]; //["黑色","黄色"]
                                let temp = {};
                                temp.attrList = [];
                                Object.assign(temp, e1);
                                //temp[cur] = e2;
                                temp.attrIndex += i; //temp = {"肤色":"黑色",attrIndex:'_0'}
                                temp.priceFee = 0;
                                temp.state = '1';
                                if(temp.state === '1'?true:false){
                                    console.log(55555555555555)
                                }
                                temp.childProductNo = '';
                                temp.skuId = this.$parent.skuId;
                                temp.stock = 0;
                                temp.attrList = temp.attrList.concat({
                                    value: cur.ProductAttrSaleValues[i].name,
                                    index: i,
                                    name: cur.name
                                });
                                result.push(temp);
                            }
                        });
                        return result;
                    },
                    [{}]
                );
                console.log(res);
                this.skuAttrList = res;
            }
        },
        addAttrSale(data) {
            let param = data;
            param.skuId = this.skuId;
            param.status = '1';
            getHttp('/productAttrSale/add', param).then(res => {
                console.log(res);
            });
        },
        addAttrSaleValue(data, valueList) {
            console.log(data);

            valueList.forEach(item => {
                let param = {};
                param.attrId = data.id;
                param.skuId = data.skuId;
                param.name = item.name;
                param.state = 1;
                getHttp('/productAttrSaleValue/add', param).then(res => {
                    console.log(res);
                    item.id = res.ProductAttrSaleValue.id;
                });
            });
        },
        updateAttrSale(data) {
            let param = {};
            param.id = data.id;
            param.name = data.name;
            getHttp('/productAttrSale/update', param).then(res => {
                console.log(res);
            });
        },
        updateAttrSaleValue(data) {
            console.log(data);
        },
        delAttrSale(data) {
            let param = {};
            param.attrId = data.id;
            param.id = data.id;
            getHttp('/productAttrSale/delete', param).then(res => {
                console.log(res);
            });
            getHttp('/productAttrSaleValue/deleteByAttrId', param).then(res => {
                console.log(res);
            });
        },
        delAttrSaleValue(data) {
            let param = {};
            param.id = data.id;
            getHttp('/productAttrSaleValue/delete', param).then(res => {
                console.log(res);
            });
        },
        delSkuExt(data) {
            console.log(data);
            let param = {};
            param.skuId = data.skuId;
            getHttp('/productSkuExt/deleteBySkuId', param).then(res => {
                console.log(res);
            });
        }
    },
    watch: {
        attrDate: {
            handler(val, oldVal) {
                this.createData();
            }
        }
    }
};
</script>

<style lang="scss" scoped>
.vue-sku {
    .spec-line {
        position: relative;
        .spec-deleted {
            position: absolute;
            right: 0;
            top: 0;
            display: none;
            cursor: pointer;
        }
        &:hover {
            .spec-deleted {
                display: inline;
            }
        }
    }
}
</style>
