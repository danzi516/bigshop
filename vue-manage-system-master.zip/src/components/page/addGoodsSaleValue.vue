<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-calendar"></i> 商品
                </el-breadcrumb-item>
                <el-breadcrumb-item>商品规格</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <SkuEdit ref="SkuEdit" :attrDate="specificationData" :cacheSpecifica="cacheSpec"></SkuEdit>
        </div>
    </div>
</template>
<script>
import SkuEdit from '../SkuEdit.vue';
import { getSaleAttr, getSaleAttrValue, getHttp, postHttp } from '@/api/index';
export default {
    name: '',
    components: { SkuEdit },
    data() {
        return {
            specificationData: [],
            cacheSpec: [],
            skuId:''
        };
    },
    created() {
        this.getInit();
    },
    methods: {
        getInit() {
            this.skuId = this.$route.query.row.id;
            getSaleAttr({ skuId: this.skuId }).then(res => {
                this.specificationData = res.ProductAttrSale;
                let resData = Object.assign([], this.specificationData);
                resData.forEach(item => {
                    item.status = false;
                });
                this.cacheSpec = resData;
            });
        },
       
    },
    computed: {}
};
</script> 
<style>
/* ---------------- el-radio-group下的el-radio-button切换为列表的形式 ---------------- */
.el-group-list.el-radio-group {
    display: flex;
    flex-direction: column;
    align-items: stretch;
    width: 120px;
    margin-left: 20px;
    height: 180px;
}

.el-group-list.el-radio-group .el-radio-button:first-child .el-radio-button__inner,
.el-group-list.el-radio-group .el-radio-button:last-child .el-radio-button__inner,
.el-group-list.el-radio-group .el-radio-button:first-child .el-radio-button__inner,
.el-group-list.el-radio-group .el-radio-button__inner {
    border-radius: 1px !important;
    border: 10px !important;
}

.el-group-list.el-radio-group .el-radio-button {
    border: 1px solid #f7f7f7 !important;
}

.el-group-list.el-radio-group {
    border: 1px solid #dcdfe6;
}

.el-radio-group.el-group-list > label > span {
    width: 100%;
    text-align: left;
    padding-left: 20px;
}
.saleAttrStyle {
    display: flex;
}
</style>
<style >
.upload-demo {
    display: flex;
}
.el-list-enter-active,
.el-list-leave-active {
    transition: none;
}

.el-list-enter,
.el-list-leave-active {
    opacity: 0;
}
</style>