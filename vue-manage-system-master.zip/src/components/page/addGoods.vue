<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-calendar"></i> 表单
                </el-breadcrumb-item>
                <el-breadcrumb-item>基本表单</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <div style="width:850px">
                <el-form ref="form" :model="form" label-width="80px">
                    <el-form-item label="名称">
                        <el-input v-model="form.name"></el-input>
                    </el-form-item>
                    <el-form-item label="简介">
                        <el-input v-model="form.desc"></el-input>
                    </el-form-item>
                    <el-form-item label="规格">
                        <el-input v-model="form.unit" placeholder="如:瓶、个、条"></el-input>
                    </el-form-item>
                    <el-form-item label="市场价">
                        <el-input
                            v-model="form.marketPriceFee"
                            maxlength="10"
                            oninput="value=value.match(/^\d*(\.?\d{0,2})/g,'')"
                            placeholder="请输入市场价金额"
                            style="width:100%"
                            clearable
                        ></el-input>
                    </el-form-item>
                    <el-form-item label="销售价格">
                        <el-input
                            v-model="form.priceFee"
                            maxlength="10"
                            oninput="value=value.match(/^\d*(\.?\d{0,2})/g,'')"
                            placeholder="请输入销售金额"
                            style="width:100%"
                            clearable
                        ></el-input>
                    </el-form-item>
					    <el-form-item label="销售规格">
                        <el-input v-model="form.saleUnit" placeholder="如:盒、箱、捆"></el-input>
                    </el-form-item>
					    <el-form-item label="销售比率">
                        <el-input v-model="form.saleUnitRate"></el-input>
                    </el-form-item>
                    <el-form-item label="主图">
                        <el-upload
                            ref="upload"
                            :action="UploadUrl()"
                            accept="image/png, image/gif, image/jpg, image/jpeg"
                            list-type="picture"
                            :file-list="mainUrlFileList"
                            :auto-upload="false"
                            :on-change="handleChange"
                        >
                            <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
                        </el-upload>
                    </el-form-item>
                    <el-form-item label="品牌">
                        <div class="block">
                            <el-cascader
                                placeholder="试试搜索"
                                :options="brandOptions"
                                :props="brandOptionProps"
                                v-model="selectedBrandOptions"
                                @change="handleChangeBrand"
                                filterable
                                clearable
                            ></el-cascader>
                        </div>
                    </el-form-item>
                    <el-form-item label="分类">
                        <div class="block">
                            <el-cascader
                                placeholder="试试搜索"
                                :options="categoryOptions"
                                :props="categoryOptionProps"
                                v-model="selectedCategoryOptions"
                                @change="handleChangeCategory"
                                filterable
                                clearable
                            ></el-cascader>
                        </div>
                    </el-form-item>
                    <el-form-item label="选择器">
                        <el-select v-model="form.region" placeholder="请选择">
                            <el-option key="bbk" label="步步高" value="bbk"></el-option>
                            <el-option key="xtc" label="小天才" value="xtc"></el-option>
                            <el-option key="imoo" label="imoo" value="imoo"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="日期时间">
                        <el-col :span="11">
                            <el-date-picker
                                type="date"
                                placeholder="选择日期"
                                v-model="form.date1"
                                value-format="yyyy-MM-dd"
                                style="width: 100%;"
                            ></el-date-picker>
                        </el-col>
                        <el-col class="line" :span="2">-</el-col>
                        <el-col :span="11">
                            <el-time-picker
                                placeholder="选择时间"
                                v-model="form.date2"
                                style="width: 100%;"
                            ></el-time-picker>
                        </el-col>
                    </el-form-item>
                    <el-form-item label="选择开关">
                        <el-switch v-model="form.delivery"></el-switch>
                    </el-form-item>
					  <!-- <el-form-item label="规格属性">
                        <SkuEdit ref="SkuEdit"></SkuEdit>
                    </el-form-item> -->

                    <el-form-item label="基础属性">
                        <el-table
                            :data="baseAttrData"
                            class="table"
                            :show-header="true"
                            :key="Math.random()"
                        >
                            <el-table-column prop="name" label="名称" width="160" align="center">
                                <template slot-scope="scope">
                                    <div>
                                        <div v-if="(0==scope.$index || 1==scope.row.handleType)">
                                            <el-input v-model="scope.row.name" size="mini"></el-input>
                                        </div>
                                        <div v-else>{{scope.row.name}}</div>
                                    </div>
                                </template>
                            </el-table-column>
                            <el-table-column prop="value" label="说明" min-width="55" align="center">
                                <template slot-scope="scope">
                                    <div>
                                        <div v-if="(0==scope.$index || 1==scope.row.handleType)">
                                            <el-input v-model="scope.row.value" size="mini"></el-input>
                                        </div>
                                        <div v-else>{{scope.row.value}}</div>
                                    </div>
                                </template>
                            </el-table-column>
                            <el-table-column label="操作" width="160" align="center">
                                <template slot-scope="scope">
                                    <div v-if="0==scope.$index">
                                        <el-button type="text" @click="onSave(scope.row)">新增</el-button>
                                    </div>
                                    <div v-else-if="1==scope.row.handleType">
                                        <el-button
                                            :loading="scope.row.saveLoading"
                                            @click="onSave(scope.row)"
                                            type="text"
                                        >保存</el-button>
                                        <el-button @click="onCancel(scope.row)" type="text">取消</el-button>
                                    </div>
                                    <div v-else>
                                        <el-button
                                            icon="el-icon-edit"
                                            @click="onEdit(scope.row)"
                                            type="text"
                                        >编辑</el-button>
                                        <el-button
                                            type="text"
                                            icon="el-icon-delete"
                                            style="color:red"
                                            @click="baseAttrDelete(scope.$index, scope.row)"
                                        >删除</el-button>
                                    </div>
                                </template>
                            </el-table-column>
                        </el-table>
                    </el-form-item>

                    

                    <el-form-item label="多选框">
                        <el-checkbox-group v-model="checkList">
                            <el-checkbox label="复选框 A"></el-checkbox>
                            <el-checkbox label="复选框 B"></el-checkbox>
                            <el-checkbox label="复选框 C"></el-checkbox>
                            <el-checkbox label="禁用" disabled></el-checkbox>
                            <el-checkbox label="选中且禁用" disabled></el-checkbox>
                        </el-checkbox-group>
                    </el-form-item>
                    <el-form-item label="单选框">
                        <el-radio-group v-model="form.resource">
                            <el-radio label="步步高"></el-radio>
                            <el-radio label="小天才"></el-radio>
                            <el-radio label="imoo"></el-radio>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item label="文本框">
                        <el-input type="textarea" rows="5" v-model="form.desc"></el-input>
                    </el-form-item>

                    <!-- <el-form-item>
                        <el-button type="primary" @click="submitForm">保存</el-button>
                        <el-button>取消</el-button>
                    </el-form-item>-->
                    <el-form-item label="详情">
                        <myTinymce ref="myTinymce" :tinymceHtml="content"></myTinymce>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" @click="submitForm">保存</el-button>
                        <el-button>取消</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </div>
        <!-- 编辑弹出框 -->
        <el-dialog title="显示" :visible.sync="editVisible" width="30%">
            <el-form ref="form" :model="form" label-width="70px">
                <el-form-item label="属性名称">
                    <el-input v-model="form.name"></el-input>
                </el-form-item>
                <el-form-item label="描述">
                    <el-input v-model="form.desc"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="editVisible = false">取 消</el-button>
                <el-button type="primary" @click="saveEdit">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
import myTinymce from '../MyTinymce';
import {
    getBaseAttr,
    getSaleAttr,
    getSaleAttrValue,
    getBrandList,
    getCategoryTree,
    addBaseAttr,
    updateBaseAttr,
    getHttp,
    postHttp
} from '@/api/index';
export default {
    name: 'addGoods',
    components: { myTinymce },
    data: function() {
        return {
            selectedCategoryOptions: '',
            categoryOptionProps: {
                value: 'id',
                label: 'label',
                children: 'children'
            },
            categoryOptions: [],
            selectedBrandOptions: '',
            brandOptionProps: {
                value: 'id',
                label: 'name',
                children: ''
            },
            brandOptions: [],
            mainUrlFileList: [],
            baseAttrValueData: [],
            checkList: ['选中且禁用', '复选框 A'],
            saleAttrList: [],
            selectedAttrId: '',
            content: '',
            form: {
                name: '',
                region: '',
                date1: '',
                date2: '',
                delivery: true,
                type: ['步步高'],
                resource: '小天才',
                desc: '',
                options: []
            },
            query: {
                address: '',
                name: '',
                pageIndex: 1,
                pageSize: 10,
                orgId: '2',
                skuId: '2',
                attrId: ''
            },
            baseAttrData: [],
            editVisible: false
        };
    },
    created() {
        this.getInit();
    },
    methods: {
         attrValueDelete(index, row) {
            console.log(index);
            console.log(row);
            // this.baseAttrData.splice(index,1)
            let data = { id: row.id };
            getHttp('/productAttrSaleValue/delete', data).then(res => {
                getSaleAttrValue(this.query).then(res => {
                console.log(res);
                this.baseAttrValueData = res.ProductAttrSaleValue;
                this.baseAttrValueData.unshift({ name: '', price: '' });
            });
             this.$message.success('删除成功');
            });
        },
        onAttrValueSave(row) {
            console.log(row);
            if (!row.name) {
                this.$message.error('属性值不能为空');
                return;
            }
            if (!row.price) {
                this.$message.error('价格不能为空');
                return;
            }
            if (!row.id) {
                let data = { name: row.name, price: row.price, skuId: this.query.skuId,attrId:this.query.attrId };
                 getHttp('/productAttrSaleValue/add', data).then(res => {
                    getSaleAttrValue(this.query).then(res => {
                console.log(res);
                this.baseAttrValueData = res.ProductAttrSaleValue;
                this.baseAttrValueData.unshift({ name: '', price: '' });
                this.$message.success('新增成功');
            });
                });
            } else {
                let data = { id: row.id, name: row.name, price: row.price};
                 getHttp('/productAttrSaleValue/update', data).then(res => {
                   getSaleAttrValue(this.query).then(res => {
                console.log(res);
                this.baseAttrValueData = res.ProductAttrSaleValue;
                this.baseAttrValueData.unshift({ name: '', price: '' });
                this.$message.success('保存成功');
            });
                });
            }
        },



        baseAttrDelete(index, row) {
            console.log(index);
            console.log(row);
            // this.baseAttrData.splice(index,1)
            let data = { id: row.id };
            getHttp('/productAttrBase/delete', data).then(res => {
                getBaseAttr(this.query).then(res => {
                    this.baseAttrData = res.ProductAttrBase;
                    this.baseAttrData.unshift({ name: '', value: '' });
                    console.log('baseAttrData=' + this.baseAttrData);
                    this.$message.success('删除成功');
                });
            });
        },
        onSave(row) {
            console.log(row);
            if (!row.name) {
                this.$message.error('名称不能为空');
                return;
            }
            if (!row.value) {
                this.$message.error('说明不能为空');
                return;
            }
            if (!row.id) {
                let data = { name: row.name, value: row.value, skuId: this.query.skuId };
                addBaseAttr(data).then(res => {
                    getBaseAttr(this.query).then(res => {
                        this.baseAttrData = res.ProductAttrBase;
                        this.baseAttrData.unshift({ name: '', value: '' });
                        console.log('baseAttrData=' + this.baseAttrData);
                        this.$message.success('新增成功');
                    });
                });
            } else {
                let data = { id: row.id, name: row.name, value: row.value, skuId: this.query.skuId };
                updateBaseAttr(data).then(res => {
                    getBaseAttr(this.query).then(res => {
                        this.baseAttrData = res.ProductAttrBase;
                        this.baseAttrData.unshift({ name: '', value: '' });
                        console.log('baseAttrData=' + this.baseAttrData);
                        this.$message.success('保存成功');
                    });
                });
            }
        },
        onCancel(row) {
            Object.assign(row, row.oldData);
            row.handleType = 0;
        },
        onEdit(row) {
            this.$set(row, 'handleType', 1);
        },
        handleChangeCategory(value) {
            console.log(value);
            console.log(this.selectedCategoryOptions);
            // this.selectedCategoryOptions = value
        },
        handleChangeBrand(value) {
            console.log(value);
            this.selectedBrandOptions = value;
        },
        handleChange(file, fileList) {
            console.log(file);
            console.log(fileList);
            this.$refs.upload.submit();
            if (fileList.length > 1) {
                fileList.splice(0, 1);
            }
            this.fileList = fileList;
            if (file.response != undefined) {
                this.fileName = file.response.data.imgPath;
            }
        },
        UploadUrl: function() {
            return 'http://127.0.0.1:7001/upload/upload?type=skuMainUrl&orgId=';
        },
        addSaleAttr() {
            console.log('点击了新增销售属性');
            this.editVisible = true;
        },
        addSaleAttrValue() {
            console.log('点击了新增销售属性的值');
        },
        submitForm() {
            console.log(this.$refs.myTinymce.value);
			this.$message.success('新增成功');
                console.log(this.$parent.$refs.vTags)
                const delItem = this.$parent.$refs.vTags.tagsList.filter(item => {
                    return item.name != this.$options.name;
                });
                this.$parent.$refs.vTags.tagsList = delItem
                this.$router.go(-1);
        },
        getInit() {
            getBaseAttr(this.query).then(res => {
                console.log('getBaseAttr.res=' + res.ProductAttrBase);
                this.baseAttrData = res.ProductAttrBase;
                this.baseAttrData.unshift({ name: '', value: '' });
                console.log('baseAttrData=' + this.baseAttrData);
            });
            getSaleAttr(this.query).then(res => {
                console.log(res);
                this.saleAttrList = res.ProductAttrSale;
            });
            getBrandList(this.query).then(res => {
                console.log(res);
                this.brandOptions = res.brand;
            });
            getCategoryTree(this.query).then(res => {
                console.log(res);
                this.categoryOptions = res.categoryNodes;
            });
        },
        changeAttr() {
            this.query.attrId = this.selectedAttrId;
            getSaleAttrValue(this.query).then(res => {
                console.log(res);
                this.baseAttrValueData = res.ProductAttrSaleValue;
                this.baseAttrValueData.unshift({ name: '', pirce: '' });
            });
        },
        handleAdd() {
            this.editVisible = true;
        },
        handleEdit(index, row) {
            this.editVisible = true;
            this.idx = index;
            this.form = Object.assign({}, row);
        },
        handleDelete() {},
        saveEdit() {
            this.editVisible = false;
        },
        onSourceCheckedChange(val, movedKeys) {
            this.leftChecked = val;
            if (movedKeys === undefined) return;
            this.$emit('left-check-change', val, movedKeys);
        }
    },
    computed: {}
};
</script> 
<style>
/* ---------------- el-radio-group下的el-radio-button切换为列表的形式 ---------------- */
.el-group-list.el-radio-group {
    display: flex;
    flex-direction: column;
    align-items: stretch;
    width: 120px;
    margin-left: 20px;
    height: 180px;
}

.el-group-list.el-radio-group .el-radio-button:first-child .el-radio-button__inner,
.el-group-list.el-radio-group .el-radio-button:last-child .el-radio-button__inner,
.el-group-list.el-radio-group .el-radio-button:first-child .el-radio-button__inner,
.el-group-list.el-radio-group .el-radio-button__inner {
    border-radius: 1px !important;
    border: 10px !important;
}

.el-group-list.el-radio-group .el-radio-button {
    border: 1px solid #f7f7f7 !important;
}

.el-group-list.el-radio-group {
    border: 1px solid #dcdfe6;
}

.el-radio-group.el-group-list > label > span {
    width: 100%;
    text-align: left;
    padding-left: 20px;
}
.saleAttrStyle {
    display: flex;
}
</style>
<style >
.upload-demo {
    display: flex;
}
.el-list-enter-active,
.el-list-leave-active {
    transition: none;
}

.el-list-enter,
.el-list-leave-active {
    opacity: 0;
}
</style>