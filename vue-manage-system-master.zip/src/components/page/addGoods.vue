<template>
<div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-calendar"></i> 表单
                </el-breadcrumb-item>
                <el-breadcrumb-item>基本表单</el-breadcrumb-item>
            </el-breadcrumb>
        </div> 
        <div class="container">
            <div style="width:850px">
                <el-form ref="form" :model="form" label-width="80px">
                    <el-form-item label="表单名称">
                        <el-input v-model="form.name"></el-input>
                    </el-form-item>
                    <el-form-item label="选择器">
                        <el-select v-model="form.region" placeholder="请选择">
                            <el-option key="bbk" label="步步高" value="bbk"></el-option>
                            <el-option key="xtc" label="小天才" value="xtc"></el-option>
                            <el-option key="imoo" label="imoo" value="imoo"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="日期时间">
                        <el-col :span="11">
                            <el-date-picker
                                type="date"
                                placeholder="选择日期"
                                v-model="form.date1"
                                value-format="yyyy-MM-dd"
                                style="width: 100%;"
                            ></el-date-picker>
                        </el-col>
                        <el-col class="line" :span="2">-</el-col>
                        <el-col :span="11">
                            <el-time-picker
                                placeholder="选择时间"
                                v-model="form.date2"
                                style="width: 100%;"
                            ></el-time-picker>
                        </el-col>
                    </el-form-item>
                    <el-form-item label="选择开关">
                        <el-switch v-model="form.delivery"></el-switch>
                    </el-form-item>
					
					  <el-form-item label="基础属性">
					  <el-button
                    type="success"
                    icon="el-icon-circle-plus-outline"
                    style="margin-left:10px"
                    @click="handleAdd"
                >新增</el-button>
                        <el-table
							:data="baseAttrData"
							class="table"
							:show-header="false"
						>
						<el-table-column prop="name" label="name" width="55" align="center"></el-table-column>
                <el-table-column prop="value" label="value" width="55" align="center"></el-table-column>
				 <el-table-column label="操作" width="180" align="center">
                    <template slot-scope="scope">
                        <el-button
                            type="text"
                            icon="el-icon-edit"
                            @click="handleEdit(scope.$index, scope.row)"
                        >编辑</el-button>
                        <el-button
                            type="text"
                            icon="el-icon-delete"
                            class="red"
                            @click="handleDelete(scope.$index, scope.row)"
                        >删除</el-button>
                    </template>
                </el-table-column>
				</el-table>
                    </el-form-item>
					
					 <el-form-item label="销售属性">
               <el-radio-group v-model="selectedAttrId" class="x-fillitem el-group-list" @change="changeAttr">
					 <!--<el-radio-button :label="-1">&lt;全部&gt;</el-radio-button>-->
					<el-radio-button v-for="(item,index) in saleAttrList" :key="index" :label="item.id">{{item.name}}</el-radio-button>
				</el-radio-group>
                    </el-form-item>
					
					
					
                    <el-form-item label="多选框">
                        <el-checkbox-group v-model="form.type">
                            <el-checkbox label="步步高" name="type"></el-checkbox>
                            <el-checkbox label="小天才" name="type"></el-checkbox>
                            <el-checkbox label="imoo" name="type"></el-checkbox>
                        </el-checkbox-group>
                    </el-form-item>
                    <el-form-item label="单选框">
                        <el-radio-group v-model="form.resource">
                            <el-radio label="步步高"></el-radio>
                            <el-radio label="小天才"></el-radio>
                            <el-radio label="imoo"></el-radio>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item label="文本框">
                        <el-input type="textarea" rows="5" v-model="form.desc"></el-input>
                    </el-form-item>
                        
                    <!-- <el-form-item>
                        <el-button type="primary" @click="submitForm">保存</el-button>
                        <el-button>取消</el-button>
                    </el-form-item> -->
                    <el-form-item label="详情"> <myTinymce ref="myTinymce" :tinymceHtml="content"></myTinymce></el-form-item>
                        <el-form-item>
                        <el-button type="primary" @click="submitForm">保存</el-button>
                        <el-button>取消</el-button>
                    </el-form-item>
                </el-form>
               
        
            </div>
        </div>
		 <!-- 编辑弹出框 -->
        <el-dialog title="编辑" :visible.sync="editVisible" width="30%">
            <el-form ref="form" :model="form" label-width="70px">
                <el-form-item label="名称">
                    <el-input v-model="form.name"></el-input>
                </el-form-item>
                <el-form-item label="数据">
                    <el-input v-model="form.value"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="editVisible = false">取 消</el-button>
                <el-button type="primary" @click="saveEdit">确 定</el-button>
            </span>
        </el-dialog>
    </div>



</template>
<script>
import myTinymce from "../MyTinymce";
import {getBaseAttr,getSaleAttr,getSaleAttrValue} from '@/api/index';
export default {
  name: "",
  components: {myTinymce},
    data: function() {
        return {
			saleAttrList:[],
			selectedAttrId:'',
            content:'',
			form: {
                name: '',
                region: '',
                date1: '',
                date2: '',
                delivery: true,
                type: ['步步高'],
                resource: '小天才',
                desc: '',
                options: []
            },
			query: {
				address: '',
				name: '',
				pageIndex: 1,
				pageSize: 10,
				orgId: '',
				skuId:'',
				attrId:''
            },
			baseAttrData:[],
			editVisible: false,
        };
    },
	created() {
        this.getInit();
    },
methods: {
		submitForm(){
		console.log(this.$refs.myTinymce.value)
		},
		getInit(){
			getBaseAttr(this.query).then(res => {
				console.log(res);
				this.baseAttrData = res.ProductAttrBase
			})
			getSaleAttr(this.query).then(res =>{
			console.log(res);
			this.saleAttrList = res.ProductAttrSale
			})
		},
		changeAttr(){
			this.query.attrId = this.selectedAttrId
			getSaleAttrValue(this.query).then(res =>{
			console.log(res);
			})
		},
        handleAdd() {
            this.editVisible = true;
        },
        handleEdit(index, row) {
            this.editVisible = true;
			this.idx = index;
            this.form = Object.assign({}, row);
        },
		saveEdit() {
            this.editVisible = false;
        },
		onSourceCheckedChange(val, movedKeys) {
        this.leftChecked = val;
        if (movedKeys === undefined) return;
        this.$emit('left-check-change', val, movedKeys);
      },
},
  computed: {
}  
};
</script> 
<style   scoped>
/* ---------------- el-radio-group下的el-radio-button切换为列表的形式 ---------------- */
.el-group-list.el-radio-group{
	display: flex;
	flex-direction: column;
	align-items:stretch;
	width:100px;
}
 
.el-group-list.el-radio-group .el-radio-button:first-child .el-radio-button__inner,
.el-group-list.el-radio-group .el-radio-button:last-child .el-radio-button__inner,
.el-group-list.el-radio-group .el-radio-button__inner
{
  border-radius: 0px !important;
  border: none !important;
  width:100%;
}
 
.el-group-list.el-radio-group .el-radio-button{
  border-bottom: 1px solid #F7F7F7 !important;
}
 
.el-group-list.el-radio-group{
  border: 1px solid #dcdfe6;
}
 
.el-group-list.el-radio-group > label > span{
  width: 100%;
  text-align: left;
  padding-left: 20px;
}
</style>