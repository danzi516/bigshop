<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-calendar"></i> 表单
                </el-breadcrumb-item>
                <el-breadcrumb-item>基本表单</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <div style="width:850px">
                <el-form ref="form" :model="form" label-width="80px">
                    

                    <el-form-item label="基础属性">
                        <!-- <el-button
                            type="success"
                            icon="el-icon-circle-plus-outline"
                            style="margin-left:10px"
                            @click="handleAdd"
                        >新增</el-button>-->
                        <el-table :data="baseAttrData" class="table" :show-header="true">
                            <el-table-column prop="name" label="名称" width="160" align="center">
                                <template slot-scope="scope">									
									 <div>
                <div v-if="(0==scope.$index || 1==scope.row.handleType)">
                  <el-input v-model="scope.row.name" size="mini"></el-input>
                </div>
                <div v-else>
                  {{scope.row.name}}
                </div>
              </div>
                                </template>
                            </el-table-column>
                            <el-table-column prop="value" label="说明" min-width="55" align="center">
							 <template slot-scope="scope">
              <div>
                <div v-if="(0==scope.$index || 1==scope.row.handleType)">
                  <el-input v-model="scope.row.value" size="mini"></el-input>
                </div>
                <div v-else>
                  {{scope.row.value}}
                </div>
              </div>
            </template>
							
							</el-table-column>
                            <el-table-column label="操作" width="160" align="center">
                                <!-- <template slot-scope="scope">
                                    <el-button
                                        type="text"
                                        icon="el-icon-edit"
                                        @click="handleEdit(scope.$index, scope.row)"
                                    >编辑</el-button>
                                    <el-button
                                        type="text"
                                        icon="el-icon-delete"
                                        class="red"
                                        @click="handleDelete(scope.$index, scope.row)"
                                    >删除</el-button>
                                </template> -->
								    <template slot-scope="scope">
              <div v-if="0==scope.$index">
                <el-button  type="text" @click="onSave(scope.row)">新增</el-button>
              </div>
              <div v-else-if="1==scope.row.handleType">
                <el-button :loading="scope.row.saveLoading"  @click="onSave(scope.row)" type="text">保存</el-button>
                <el-button @click="onCancel(scope.row)" type="text">取消</el-button>
              </div>
              <div v-else>
                <el-button @click="onEdit(scope.row)" type="text">编辑</el-button>
                <span >
                  <el-button v-if="scope.row.status==0" @click="onFreez(scope.row)" type="text">冻结</el-button>
                  <el-button v-if="scope.row.status==1" @click="onUnfreez(scope.row)" type="text">解冻</el-button>
                  <el-button @click="onChangePassword(scope.row)" type="text">设置密码</el-button>
                  <!-- <el-button @click="onChatRec(scope.row)" type="text">聊天记录</el-button> -->
                </span>
              </div>
            </template>
                            </el-table-column>
                        </el-table>
                    </el-form-item>
			</el-form>
             </div>  
		</div>			 
    </div>
</template>
<script>
import myTinymce from '../MyTinymce';
import { getBaseAttr, getSaleAttr, getSaleAttrValue, getBrandList, getCategoryTree } from '@/api/index';
export default {
    name: '',
    components: { myTinymce },
    data: function() {
        return {
		
            selectedCategoryOptions: '',
            categoryOptionProps: {
                value: 'id',
                label: 'label',
                children: 'children'
            },
            categoryOptions: [],
            selectedBrandOptions: '',
            brandOptionProps: {
                value: 'id',
                label: 'name',
                children: ''
            },
            brandOptions: [],
            mainUrlFileList: [],
            baseAttrValueData: [],
            checkList: ['选中且禁用', '复选框 A'],
            saleAttrList: [],
            selectedAttrId: '',
            content: '',
            form: {
                name: '',
                region: '',
                date1: '',
                date2: '',
                delivery: true,
                type: ['步步高'],
                resource: '小天才',
                desc: '',
                options: []
            },
            query: {
                address: '',
                name: '',
                pageIndex: 1,
                pageSize: 10,
                orgId: '2',
                skuId: '',
                attrId: ''
            },
            baseAttrData: [{ name: '', value: '' }],
            editVisible: false
        };
    },
    created() {
        this.getInit();
    },
    methods: {
	onSave(row) {},
	onCancel(row){Object.assign(row, row.oldData);
      row.handleType = 0;},
		onEdit(row) {this.$set(row, 'handleType', 1);},
        handleChangeCategory(value) {
            console.log(value);
            console.log(this.selectedCategoryOptions);
            // this.selectedCategoryOptions = value
        },
        handleChangeBrand(value) {
            console.log(value);
            this.selectedBrandOptions = value;
        },
        handleChange(file, fileList) {
            console.log(file);
            console.log(fileList);
            this.$refs.upload.submit();
            if (fileList.length > 1) {
                fileList.splice(0, 1);
            }
            this.fileList = fileList;
            if (file.response != undefined) {
                this.fileName = file.response.data.imgPath;
            }
        },
        UploadUrl: function() {
            return 'http://127.0.0.1:7001/upload/upload?type=skuMainUrl&orgId=';
        },
        addSaleAttr() {
            console.log('点击了新增销售属性');
            this.editVisible = true;
        },
        addSaleAttrValue() {
            console.log('点击了新增销售属性的值');
        },
        submitForm() {
            console.log(this.$refs.myTinymce.value);
        },
        getInit() {
            getBaseAttr(this.query).then(res => {
                console.log('getBaseAttr.res=' + res.ProductAttrBase);
                this.baseAttrData = this.baseAttrData.concat(res.ProductAttrBase);
                console.log('baseAttrData=' + this.baseAttrData);
            });
            getSaleAttr(this.query).then(res => {
                console.log(res);
                this.saleAttrList = res.ProductAttrSale;
            });
            getBrandList(this.query).then(res => {
                console.log(res);
                this.brandOptions = res.brand;
            });
            getCategoryTree(this.query).then(res => {
                console.log(res);
                this.categoryOptions = res.categoryNodes;
            });
        },
        changeAttr() {
            this.query.attrId = this.selectedAttrId;
            getSaleAttrValue(this.query).then(res => {
                console.log(res);
                this.baseAttrValueData = res.ProductAttrSaleValue;
            });
        },
        handleAdd() {
            this.editVisible = true;
        },
        handleEdit(index, row) {
            this.editVisible = true;
            this.idx = index;
            this.form = Object.assign({}, row);
        },
        handleDelete() {},
        saveEdit() {
            this.editVisible = false;
        },
        onSourceCheckedChange(val, movedKeys) {
            this.leftChecked = val;
            if (movedKeys === undefined) return;
            this.$emit('left-check-change', val, movedKeys);
        }
    },
    computed: {}
};
</script> 
<style>
/* ---------------- el-radio-group下的el-radio-button切换为列表的形式 ---------------- */
.el-group-list.el-radio-group {
    display: flex;
    flex-direction: column;
    align-items: stretch;
    width: 120px;
    margin-left: 20px;
    height: 180px;
}

.el-group-list.el-radio-group .el-radio-button:first-child .el-radio-button__inner,
.el-group-list.el-radio-group .el-radio-button:last-child .el-radio-button__inner,
.el-group-list.el-radio-group .el-radio-button:first-child .el-radio-button__inner,
.el-group-list.el-radio-group .el-radio-button__inner {
    border-radius: 0px !important;
    border: none !important;
}

.el-group-list.el-radio-group .el-radio-button {
    border-bottom: 0px solid #f7f7f7 !important;
}

.el-group-list.el-radio-group {
    border: 0.5px solid #dcdfe6;
}

.el-radio-group.el-group-list > label > span {
    width: 100%;
    text-align: left;
    padding-left: 20px;
}
.saleAttrStyle {
    display: flex;
}
</style>
<style >
.upload-demo {
    display: flex;
}
.el-list-enter-active,
.el-list-leave-active {
    transition: none;
}

.el-list-enter,
.el-list-leave-active {
    opacity: 0;
}
</style>