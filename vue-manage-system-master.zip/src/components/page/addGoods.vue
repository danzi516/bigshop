<template>
<div class="container">
            <div style="width:850px">
  <div class="vue-sku">
    <!-- 规格设置 -->
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>产品规格设置</span>
      </div>
      <section>
        <div v-for="(item, index) in specification" :key="index" class="spec-line">
          <div>
            <span v-if="!cacheSpecification[index].status">{{ item.attrName.name }}</span>
            <el-input size="small" style="width:200px;"  v-if="cacheSpecification[index].status" v-model="cacheSpecification[index].name" placeholder="输入产品规格" @keyup.native.enter="saveSpec(index)">
              <el-button slot="append" icon="el-icon-check" type="primary" @click="saveSpec(index)"></el-button>
            </el-input>
            <i class="icon el-icon-edit" v-if="!cacheSpecification[index].status" @click="updateSpec(index)"></i>
          </div>
          <div>
            <el-tag v-for="(tag, j) in item.attrValue" :key="j" closable  @close="delSpecTag(index, j)">{{ tag.name }}</el-tag>
            <el-input size="small" style="width:200px;" v-model="addValues[index]" placeholder="多个产品属性以空格隔开" @keyup.native.enter="addSpecTag(index)">
              <el-button slot="append" icon="el-icon-check" type="primary" @click="addSpecTag(index)"></el-button>
            </el-input>
          </div>
          <i class="icon el-icon-circle-close spec-deleted" @click="delSpec(index)"></i>
          <el-divider></el-divider>
        </div>
        <div class="add-spec">
          <el-button size="small" type="primary" :disabled="specification.length >= 5" @click="addSpec">添加规格项目</el-button>
        </div>
      </section>
    </el-card>
	
	
	<el-card>
      <div slot="header" class="clearfix">
        <span>规格表格</span>
      </div>
      <table class="el-table" cellspacing="0" cellpadding="0">
        <thead>
        <tr>
          <th
            v-for="(item, index) in specificationReal"
            :key="index">
            {{item.attrName.name}}
          </th>
          <th style="width: 160px;">商品编码</th>
          <th style="width: 70px;">库存</th>
          <th style="width: 100px;">销售价（元）</th>
          <th>是否启用</th>
        </tr>
        </thead>
        <tbody v-if="specificationReal[0] && specificationReal[0].attrValue.length">
        <tr
          :key="index"
          v-for="(item, index) in skuAttrList">
          <template v-for="(n, specIndex) in item.attrList">
            <td
             
              :key="specIndex"
              :rowspan="n.length">
              {{n.value}}
            </td>
          </template>
          <td>
            <el-input
              size="small"
              type="text"
              :disabled="!item.isUse"
              v-model="item.childProductNo"
              placeholder="输入商品编号">
            </el-input>
          </td>
    
          <td>
            <el-input
              size="small"
              type="text"
              v-model.number="item.stock"
              placeholder="输入库存"
              :disabled="!item.isUse">
            </el-input>
          </td>
          <td>
            <el-input
              size="small"
              type="text"
              v-model.number="item.price"
              placeholder="输入销售价"
              :disabled="!item.isUse">
            </el-input>
          </td>
          <td>
            <el-switch v-model="item.isUse" @change="(val) => {handleUserChange(index, val)}"></el-switch>
          </td>
        </tr>
        <tr>
          <td colspan="8" class="wh-foot">
            <span class="label">批量设置：</span>
            <template v-if="isSetListShow">
              <el-button @click="openBatch('childProductCost')" size="mini">成本价</el-button>
              <el-button @click="openBatch('childProductStock')" size="mini">库存</el-button>
              <el-button @click="openBatch('childProductPrice')" size="mini">销售价</el-button>
            </template>
            <template v-else>
              <el-input size="mini" style="width:200px;" v-model.number="batchValue" placeholder="输入要设置的数量"></el-input>
              <el-button type="primary" size="mini" @click="setBatch"><i class="set-btn blue el-icon-check"></i></el-button>
              <el-button type="danger" size="mini" @click="cancelBatch"><i class="set-btn blue el-icon-close"></i></el-button>
            </template>
          </td>
        </tr>
        </tbody>

      </table>
    </el-card>
</div>
 <span slot="footer" class="dialog-footer">
                <el-button @click="editVisible = false">取 消</el-button>
                <el-button type="primary" @click="saveEdit">确 定</el-button>
            </span>
</div>
</div>
</template>

<script>

  // 为Object添加一个原型方法，判断两个对象是否相等
  function objEquals (object1, object2) {
    // For the first loop, we only check for types
    for (let propName in object1) {
      // Check for inherited methods and properties - like .equals itself
      // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/hasOwnProperty
      // Return false if the return value is different
      if (object1.hasOwnProperty(propName) !== object2.hasOwnProperty(propName)) {
        return false
        // Check instance type
      } else if (typeof object1[propName] !== typeof object2[propName]) {
        // Different types => not equal
        return false
      }
    }
    // Now a deeper check using other objects property names
    for (let propName in object2) {
      // We must check instances anyway, there may be a property that only exists in object2
      // I wonder, if remembering the checked values from the first loop would be faster or not
      if (object1.hasOwnProperty(propName) !== object2.hasOwnProperty(propName)) {
        return false
      } else if (typeof object1[propName] !== typeof object2[propName]) {
        return false
      }
      // If the property is inherited, do not check any more (it must be equa if both objects inherit it)
      if (!object1.hasOwnProperty(propName)) {
        continue
      }
      // Now the detail check and recursion
      // This returns the script back to the array comparing
      /** REQUIRES Array.equals**/
      if (object1[propName] instanceof Array && object2[propName] instanceof Array) {
        // recurse into the nested arrays
        if (objEquals(!object1[propName], object2[propName])) {
          return false
        }
      } else if (object1[propName] instanceof Object && object2[propName] instanceof Object) {
        // recurse into another objects
        // console.log("Recursing to compare ", this[propName],"with",object2[propName], " both named \""+propName+"\"");
        if (objEquals(!object1[propName], object2[propName])) {
          return false
        }
        // Normal value comparison for strings and numbers
      } else if (object1[propName] !== object2[propName]) {
        return false
      }
    }
    // If everything passed, let's say YES
    return true
  }

  export default {
    name: 'app',

    data () {
      return {
        specificationStatus: false, // 显示规格列表
        // 规格
        specification: [],
		specificationReal: [],
        // 子规格
        childProductArray: [],
        // 用来存储要添加的规格属性
        addValues: [],
        // 默认商品编号
        defaultProductNo: 'PRODUCTNO_',
        // 批量设置相关
        isSetListShow: true,
        batchValue: '', // 批量设置所绑定的值
        currentType: '', // 要批量设置的类型
        cacheSpecification: [], // 缓存规格名称
		skuAttrList:[]
      }
    },

    computed: {
      // 所有sku的id
      stockSpecArr () {
        return this.childProductArray.map(item => item.childProductSpec)
      }
    },
    created() {
      this.createData()
    },
    methods: {
      // 创建模拟数据
      createData() {

		this.specification = [
        {
            "attrName": {"name":"保存"},
            "attrValue": [{"name":"冷冻"}, {"name":"常温"}]
        },
        {
            "attrName": {"name":"年龄"},
            "attrValue": [{"name":"18"},{"name":"20"}]
        }]
		this.cacheSpecification = [{
			status: false,
            name: "保存"},
			{
			status: false,
            name: "年龄"}
		]

		this.skuProperties()
      },
      // 添加规格项目
      addSpec () {
        if (this.specification.length < 5) {
          this.cacheSpecification.push({
            status: true,
            name: ''
          })
          this.specification.push({
            attrName: {},
            attrValue: []
          })
        }
      },
      // 修改状态
      updateSpec(index) {
        this.cacheSpecification[index].status = true
        this.cacheSpecification[index].name = this.specification[index].attrName.name
      },
      // 保存规格名
      saveSpec(index) {
        if (!this.cacheSpecification[index].name.trim()) {
          this.$message.error('名称不能为空，请注意修改')
          return
        }
        // 保存需要验证名称是否重复
        if (this.specification[index].attrName.name === this.cacheSpecification[index].name) {
          this.cacheSpecification[index].status = false
        } else {

          if (this.verifyRepeat(index)) {
            // 如果有重复的，禁止修改
            this.$message.error('名称重复，请注意修改')
          } else {
            this.specification[index].attrName.name = this.cacheSpecification[index].name
            this.cacheSpecification[index].status = false
          }
        }
      },
      // 删除规格项目
      delSpec (index) {
        this.specification.splice(index, 1)
        this.skuProperties()
        this.handleSpecChange('del')
		
      },
      verifyRepeat(index) {
        let flag = false
        this.specification.forEach((value, j) => {
          // 检查除了当前选项以外的值是否和新的值想等，如果相等，则禁止修改
          if (index !== j) {
            if (this.specification[j].attrName.name === this.cacheSpecification[index].name) {
              flag = true
            }
          }
        })
        return flag
      },
      // 添加规格属性
      addSpecTag (index) {
        let str = this.addValues[index] || ''
        if (!str.trim() || !this.cacheSpecification[index].name.trim()) {
          this.$message.error('名称不能为空，请注意修改')
          return
        } // 判空
        str = str.trim()
        let arr = str.split(/\s+/) // 使用空格分割成数组
		arr = Array.from(new Set(arr)) // 去重
		let valueList = []
		for(let i=0;i<arr.length;i++){
			let value={}
			value.name=arr[i]
			valueList.push(value)
		}
        let newArr = this.specification[index].attrValue.concat(valueList)
        
        this.$set(this.specification[index], 'attrValue', newArr)

        this.clearAddValues(index)

        this.handleSpecChange('add')

		console.log(this.specification)
		
        this.specification[index].attrName.name = this.cacheSpecification[index].name
        this.cacheSpecification[index].status = false
		this.skuProperties()
      },
	skuProperties(){
    		this.specificationReal = this.specification.filter(item=>{
		return item.attrName.name!=null && item.attrValue.length!=0
	})
      console.log(this.specificationReal)

	   let res = this.specificationReal.reduce((pre,cur)=>{
        let result = [];
        pre.forEach(e1=>{ // e1 {}
            //cur {"attrName":"肤色",attrValue:["黑色","黄色"]}
            //sku_index    位置  索引值   0_0_0
            e1.sku_index = (e1.sku_index||'')+"_";  // e1 = {sku_index:'_'}
            for(let i=0;i<cur.attrValue.length;i++){
                let e2 = cur.attrValue[i]; //["黑色","黄色"]
                let temp = {}
				temp.attrList = []
                Object.assign(temp,e1);
                //temp[cur.attrName] = e2;
                temp.sku_index += i;//temp = {"肤色":"黑色",sku_index:'_0'}
				temp.attrList = temp.attrList.concat({value:cur.attrValue[i].name,index:i,name:cur.attrName.name})
				temp.price=0
				temp.stock=0
        temp.isUse=true
        temp.childProductNo=''
                result.push(temp);
            }
        })
        return result;
    },[{}])
	console.log(res)
	this.skuAttrList = res
	},
	getAttrValue(){
	
	},
      // 删除规格属性
      delSpecTag (index, num) {
        this.specification[index].attrValue.splice(num, 1)

        //this.handleSpecChange('del')

		this.skuProperties()
      },

      // 清空 addValues
      clearAddValues (index) {
        this.$set(this.addValues, index, '')
      },




      /**
       * [handleSpecChange 监听标签的变化,当添加标签时；求出每一行的hash id，再动态变更库存信息；当删除标签时，先清空已有库存信息，然后将原有库存信息暂存到stockCopy中，方便后面调用]
       * @param  {[string]} option ['add'|'del' 操作类型，添加或删除]
       * @return {[type]}        [description]
       */
      handleSpecChange (option) {
        const stockCopy = JSON.parse(JSON.stringify(this.childProductArray))
        if (option === 'del') {
          this.childProductArray = []
        }

        // for (let i = 0; i < this.countSum(0); i++) {
        //   this.changeStock(option, i, stockCopy)
        // }
      },

      /**
       * [根据规格，动态改变库存相关信息]
       * @param  {[string]} option    ['add'|'del' 操作类型，添加或删除]
       * @param  {[array]} stockCopy [库存信息的拷贝]
       * @return {[type]}           [description]
       */
      changeStock (option, index, stockCopy) {
        let childProduct = {
          childProductId: 0,
          childProductSpec: this.getChildProductSpec(index),
          childProductNo: this.defaultProductNo + index,
          childProductStock: 0,
          childProductPrice: 0,
          childProductCost: 0,
          isUse: true,
		  childProductAttr:0
        }

        const spec = childProduct.childProductSpec
        if (option === 'add') {
          // 如果此id不存在，说明为新增属性，则向 childProductArray 中添加一条数据
          if (this.stockSpecArr.findIndex((item) => objEquals(spec, item)) === -1) {
            this.$set(this.childProductArray, index, childProduct)
          }
        } else if (option === 'del') {
          // 因为是删除操作，理论上所有数据都能从stockCopy中获取到
          let origin = ''
          stockCopy.forEach(item => {
            if (objEquals(spec, item.childProductSpec)) {
              origin = item
              return false
            }
          })
          this.childProductArray.push(origin || childProduct)
        }
      },


      // 监听规格启用操作
      handleUserChange (index, value) {
        // 启用规格时，生成不重复的商品编号；关闭规格时，清空商品编号
        if (value) {
          let No = this.makeProductNoNotRepet(index)
          this.$set(this.childProductArray[index], 'childProductNo', No)
        } else {
          this.$set(this.childProductArray[index], 'childProductNo', '')
        }
      },

    

      // 生成不重复的商品编号
      makeProductNoNotRepet (index) {
        let No
        let i = index
        let isRepet = true
        while (isRepet) {
          No = this.defaultProductNo + i
          isRepet = this.isProductNoRepet(No)
          i++
        }
        return No
      },

      // 商品编号判重
      isProductNoRepet (No) {
        const result = this.childProductArray.findIndex((item) => {
          return item.childProductNo === No
        })
        return result > -1
      },

      // 打开设置框
      openBatch (type) {
        this.currentType = type
        this.isSetListShow = false
      },

      // 批量设置
      setBatch () {
        if (typeof this.batchValue === 'string') {
          this.$message({
            type: 'warning',
            message: '请输入正确的值'
          })
          return
        }
        this.childProductArray.forEach(item => {
          if (item.isUse) {
            item[this.currentType] = this.batchValue
          }
        })

        this.cancelBatch()
      },

      // 取消批量设置
      cancelBatch () {
        this.batchValue = ''
        this.currentType = ''
        this.isSetListShow = true
      },
           saveEdit() {
            console.log(this.skuAttrList)
        },

    }
  }
</script>

<style lang="scss" scoped>
  .vue-sku{
    .spec-line{position:relative;
      .spec-deleted{position:absolute;right:0;top:0;display: none;cursor: pointer;}
      &:hover{
        .spec-deleted{display: inline;}
      }
    }
  }
</style>
