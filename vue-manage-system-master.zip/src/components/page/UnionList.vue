<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item>
                    <i class="el-icon-lx-cascades"></i> 基础表格
                </el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <div class="handle-box">
            
                <el-select v-model="query.address" placeholder="aaaaaaaaaaaa" class="handle-select mr10">
                    <el-option key="1" label="11111" value="1111"></el-option>
                    <el-option key="2" label="22222" value="22222"></el-option>
                </el-select>
<el-input v-model="query.name" placeholder="用户名" class="handle-input mr10"></el-input>
                <el-button type="primary" icon="el-icon-search" @click="handleSearch">search</el-button>
                <el-button type="success" icon="el-icon-circle-plus-outline" style="margin-left:100px" @click="handleAdd">add</el-button>
            </div>
            <el-table
                :data="tableData"
                border
                class="table"
                ref="multipleTable"
                header-cell-class-name="table-header"
                @selection-change="handleSelectionChange"
            >
               
                <el-table-column prop="Union.id" label="ID" width="55" align="center"></el-table-column>
                <el-table-column prop="Union.name" label="name"></el-table-column>
                <el-table-column label="logo图片(查看大图)" align="center">
                    <template slot-scope="scope">
                        <el-image
                            class="table-td-thumb"
                            :src="'http://127.0.0.1:7001/public'+scope.row.Union.logo"
                            :preview-src-list="[scope.row.Union.logo]"
                        ></el-image>
                    </template>
                </el-table-column>
               
				<el-table-column prop="organ.name" label="盟主"></el-table-column>
                <el-table-column prop="Union.banner" label="轮播图" align="center"></el-table-column>
                <el-table-column prop="Union.creatTime" label="创建时间"></el-table-column>
                <el-table-column label="操作" width="180" align="center">
                    <template slot-scope="scope">
						<el-button
							v-if="scope.row.Union.ower !=orgId"
                            type="text"    
                            @click="viewUnion(scope.$index, scope.row)"
                        >查看</el-button>
							<el-button
							v-if="scope.row.Union.ower ===orgId"
                            type="text"    
                            @click="managerUnion(scope.$index, scope.row)"
                        >管理</el-button>
                        <el-button
							v-if="scope.row.Union.ower ===orgId"
                            type="text"                       
                            @click="editUnion(scope.$index, scope.row)"
                        >编辑</el-button>
                        <el-button
                            type="text"                
                            class="red"
                            @click="delUnion(scope.$index, scope.row)"
                        >删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div class="pagination">
                <el-pagination
                    background
                    layout="total, prev, pager, next"
                    :current-page="query.pageIndex"
                    :page-size="query.pageSize"
                    :total="pageTotal"
                    @current-change="handlePageChange"
                ></el-pagination>
            </div>
        </div>

        <!-- 编辑弹出框 -->
        <el-dialog title="操作" :visible.sync="editVisible" width="25%">
            <el-form ref="form" :model="form" label-width="90px">
                <el-form-item label="名称">
                    <el-input v-model="form.name" style="width:200px"></el-input>
                </el-form-item>
                 <el-form-item label="logo图片">
                    <!-- <el-input v-model="form.address"></el-input> -->
                      <el-upload
                        ref="uploadLogo"
                        :action="UploadUrl()"
                        accept="image/png, image/gif, image/jpg, image/jpeg"
                        list-type="picture"
                        :file-list="fileList"
                        :auto-upload="false"
                        :on-change="handleChange"
                    >
                        <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
                    </el-upload>
					
                </el-form-item>
				      <el-form-item label="banner图片">
                   
                    <el-upload
                        ref="uploadBanner"
                        :action="UploadBannerUrl()"
                        accept="image/png, image/gif, image/jpg, image/jpeg"
                        list-type="picture"
                        :file-list="bannerList"
                        :auto-upload="false"
                        :on-change="bannerChange"
                    >
                        <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
                    </el-upload>
					
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="editVisible = false">取 消</el-button>
                <el-button type="primary" @click="saveEdit">确 定</el-button>
            </span>
        </el-dialog>
		
		        <!-- 管理弹出框 -->
        <el-dialog title="操作" :visible.sync="managerUnionVisible" width="80%">
             <el-table
                :data="tableUnionData"
                border
                class="table"
                ref="unionTable"
                header-cell-class-name="table-header"
                @selection-change="handleSelectionChange"
            >
               
                <el-table-column prop="organ.id" label="ID" width="55" align="center">
					<template slot-scope="scope">
                                    <div>
                                        <div v-if="0==scope.$index">
                                           --
                                        </div>
                                        <div v-else>{{scope.row.organ.id}}</div>
                                    </div>
                                </template></el-table-column>
                <el-table-column prop="organ.name" label="名称">
				<template slot-scope="scope">
                                    <div>
                                        <div v-if="0==scope.$index">
                                           {{organ.name}}
                                        </div>
                                        <div v-else>{{scope.row.organ.name}}</div>
                                    </div>
                                </template></el-table-column>
				<el-table-column prop="organ.bossName" label="老板名称">
		<template slot-scope="scope">
                                    <div>
                                        <div v-if="0==scope.$index">
                                           {{organ.bossName}}
                                        </div>
                                        <div v-else>{{scope.row.organ.bossName}}</div>
                                    </div>
                                </template>			</el-table-column>   	
				<el-table-column prop="organ.bossPhone" label="联系方式">
				<template slot-scope="scope">
                                    <div>
                                        <div v-if="0==scope.$index">
                                            <div class="block">
							 <el-autocomplete
  v-model="organ.bossPhone"
  ref="organInfo"
  :trigger-on-focus="false" 
  :fetch-suggestions="querySearchAsync"
  placeholder="请输入内容"
  @select="handleSelect"
  clearable

></el-autocomplete>
                        </div>
                                        </div>
                                        <div v-else>{{scope.row.organ.bossPhone}}</div>
                                    </div>
                                </template>
				</el-table-column>
				
                <el-table-column prop="organ.address" label="地址" align="center">
					<template slot-scope="scope">
                                    <div>
                                        <div v-if="0==scope.$index">
                                           {{organ.address}}
                                        </div>
                                        <div v-else>{{scope.row.organ.address}}</div>
                                    </div>
                                </template>	</el-table-column>
                <el-table-column prop="creatAt" label="加入时间">
					<template slot-scope="scope">
                                    <div>
                                        <div v-if="0==scope.$index">
                                           {{organ.creatAt}}
                                        </div>
                                        <div v-else>{{scope.row.creatAt}}</div>
                                    </div>
                                </template>
				</el-table-column>
                <el-table-column label="操作" width="180" align="center">
                    <template slot-scope="scope">
						<div v-if="0==scope.$index">
                                        <el-button type="text" @click="addOrgToUnion(scope.row)">新增</el-button>
                                    </div>
                       
                       <div v-else>
                                        <el-button
                                            type="text"
                                            icon="el-icon-delete"
                                            style="color:red"
                                            @click="baseAttrDelete(scope.$index, scope.row)"
                                        >删除</el-button>
                                    </div>
                    </template>
                </el-table-column>
            </el-table>
            
        </el-dialog>
		   <el-dialog title="操作" :visible.sync="viewUnionVisible" width="80%">
             <el-table
                :data="tableViewUnionData"
                border
                class="table"
                ref="viewUnionTable"
                header-cell-class-name="table-header"
                @selection-change="handleSelectionChange"
            >
               
                <el-table-column prop="organ.id" label="ID" width="55" align="center"></el-table-column>   		
                <el-table-column prop="organ.name" label="名称"></el-table-column>   
				<el-table-column prop="organ.bossName" label="老板名称"></el-table-column>   	
				<el-table-column prop="organ.bossPhone" label="联系方式"></el-table-column>
                <el-table-column prop="organ.address" label="地址" align="center"></el-table-column>
                <el-table-column prop="creatAt" label="加入时间"></el-table-column>
                
            </el-table>
            
        </el-dialog>
    </div>

</template>
<script>
import { fetchData, getCategoryByPage,getCategoryInfo,getHttp } from '../../api/index';
export default {
    name: 'basetable',
    data() {
        return { 
            query: {
				orgId:'',
                name: '',
                pageIndex: 1,
                pageSize: 10,
				level:''
            },
			orgId:2,
            tableData: [],
			tableUnionData: [],
			tableViewUnionData:[],
            multipleSelection: [],
            delList: [],
            editVisible: false,
			managerUnionVisible:false,
			viewUnionVisible:false,
            pageTotal: 0,
            form: {},
            idx: -1,
            id: -1,
			fileList:[],
			bannerList:[],
			options:[],
			selectAll:0,
			orgOptions:[],
			organ:'',
			isAble:false
        };
    },
    created() {
        this.getData();
    },
    methods: {
	    handleChange(file, fileList) {
            console.log(file.name); 
            console.log(fileList); 
			this.$refs.uploadLogo.submit();
            if (fileList.length > 1) {
                fileList.splice(0, 1);
            }
			this.fileList = fileList;
            if(file.response!=undefined){
this.fileName = file.response.data.imgPath
            }
        },
		    bannerChange(file, bannerList) {
            console.log(file.name); 
            console.log(bannerList); 
           
        },

       getData() {
            this.query.orgId = 2;
			 getHttp('/unionOrgan/infoByPage', this.query).then(res => {
                console.log(res);
				 this.tableData = res.record.rows;
            this.pageTotal = res.record.count || 10;
            });
            
           
            
        },
		UploadUrl:function(){
        return "http://127.0.0.1:7001/upload/upload?type=unionLogo&orgId=2";     
    },
		UploadBannerUrl:function(){
        return "http://127.0.0.1:7001/upload/upload?type=unionBanner&orgId=2";     
    },
        // 触发搜索按钮
        handleSearch() {
            this.$set(this.query, 'pageIndex', 1);
            this.getData();
        },
        // 删除操作
        handleDelete(index, row) {
            // 二次确认删除
            this.$confirm('确定要删除吗？', '提示', {
                type: 'warning'
            })
                .then(() => {
                    this.$message.success('删除成功');
                    this.tableData.splice(index, 1);
                })
                .catch(() => {});
        },
        // 多选操作
        handleSelectionChange(val) {
            this.multipleSelection = val;
        },
        delAllSelection() {
            const length = this.multipleSelection.length;
            let str = '';
            this.delList = this.delList.concat(this.multipleSelection);
            for (let i = 0; i < length; i++) {
                str += this.multipleSelection[i].name + ' ';
            }
            this.$message.error(`删除了${str}`);
            this.multipleSelection = [];
        },
        //新增操作
      async  handleAdd(){
		
            this.editVisible = true;
			this.form.name = ''; 
			this.fileList=[]; 
        },
	querySearchAsync(queryString, cb) {
        //var restaurants = this.restaurants;
		let param = {}
		param.bossPhone = queryString
		console.log(queryString.length)
		cb([])
		if(queryString.length>3){
			getHttp('/organ/info', param).then(res => {
		   let list = res.Organ
		   for(let item of res.Organ) {
		   item.value = item.bossPhone
		   }
		   cb(list)
		})
		}
      },
  
      handleSelect(item) {
        console.log(item);
		this.isAble = true;
		this.organ = item;
      }
   ,
		managerUnion(index, row) {
		console.log(row);
		this.organ={};
				let param = {}
				param.unionId = row.unionId
			 getHttp('/unionOrgan/info', param).then(res => {
                console.log(res);
				this.tableUnionData = res.record;
				this.tableUnionData.unshift({ organ: '', creatTime: '' });
				this.managerUnionVisible = true;
            });
		},
		viewUnion(index, row){
			console.log(row);
		this.organ={};
				let param = {}
				param.unionId = row.unionId
			 getHttp('/unionOrgan/info', param).then(res => {
                console.log(res);
				this.tableViewUnionData = res.record;
				this.viewUnionVisible = true;
            });
		},
        // 编辑操作
      editUnion(index, row) {
	  		this.query.orgId = 2;
			this.query.level = 1;
        
            this.idx = index;
            // this.form = row;
            this.form = Object.assign({}, row)
            this.selectAll = this.form.pid;
			this.fileList=[]; 
			this.fileList.push({name:'', url: 'http://127.0.0.1:7001/public'+row.logo});
            this.editVisible = true;
        },
        // 保存编辑
        saveEdit() {
            this.editVisible = false;
            this.$message.success(`修改第 ${this.idx + 1} 行成功`);
            this.$set(this.tableData, this.idx, this.form);
        },
        // 分页导航
        handlePageChange(val) {
            this.$set(this.query, 'pageIndex', val);
            this.getData();
        }
    }
};
</script>

<style scoped>
.handle-box {
    margin-bottom: 20px;
}

.handle-select {
    width: 120px;
}

.handle-input {
    width: 300px;
    display: inline-block;
}
.table {
    width: 100%;
    font-size: 14px;
}
.red {
    color: #ff0000;
}
.mr10 {
    margin-right: 10px;
}
.table-td-thumb {
    display: block;
    margin: auto;
    width: 40px;
    height: 40px;
}
</style>
<style >
.upload-demo {
    display: flex;
}
.el-list-enter-active,
.el-list-leave-active {
    transition: none;
}

.el-list-enter,
.el-list-leave-active {
    opacity: 0;
}
.el-upload-list {
    height: 40px;
}
</style>