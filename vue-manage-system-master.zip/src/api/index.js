import request from '../utils/request';
var baseUrl = "http://127.0.0.1:7001";
var uploadURL = "http://127.0.0.1:7001/upload/upload"
export const fetchData = query => {
    return request({
        url: './table.json',
        method: 'get',
        params: query
    });
};

export  function getHttp(url,query){
    return  request({
       url: baseUrl+url,
       method: 'get',
       params: query
   });
};

export  function postHttp(url,query){
    return  request({
       url: baseUrl+url,
       method: 'post',
       params: query
   });
};

export  function getProviceList(){
     return  request({
        url: baseUrl+'/area/getProviceList',
        method: 'get',
    });
};
export  function  getCityList(id){
    return  request({
        url: baseUrl+'/area/getCityList',
        method: 'get',
        params: {id:id}
    });
};
export  function getAreaList(id){
    return  request({
        url: baseUrl+'/area/getAreaList',
        method: 'get',
        params: {id:id}
    });
};

export  function getBrandByPage(query){
    return  request({
        url: baseUrl+'/brand/findByPage',
        method: 'get',
        params: query
    });
};

export  function getBrandList(query){
    return  request({
        url: baseUrl+'/brand/info',
        method: 'get',
        params: query
    });
};

export  function addBrand(record){
    return  request({
        url: baseUrl+'/brand/add',
        method: 'get',
        params: record
    });
};

export  function getCategoryByPage(query){
    return  request({
        url: baseUrl+'/category/findByPage',
        method: 'get',
        params: query
    });
};

export  function getSkuByPage(query){
    return  request({
        url: baseUrl+'/productSku/findByPage',
        method: 'get',
        params: query
    });
};

export  function getCategoryTree(query){
    return  request({
        url: baseUrl+'/category/findByTree',
        method: 'get',
        params: query
    });
};

export  function getCategoryInfo(query){
    return  request({
        url: baseUrl+'/category/info',
        method: 'get',
        params: query
    });
};

export  function uploadImg(query){
    return  request({
        url: uploadURL,
        method: 'post',
        data: query,
        headers:{"Content-Type": "multipart/form-data"}
    });
};

export  function getBaseAttr(query){
    return  request({
        url: baseUrl+'/productAttrBase/info',
        method: 'get',
        params: query
    });
};

export  function addBaseAttr(query){
    return  request({
        url: baseUrl+'/productAttrBase/add',
        method: 'get',
        params: query
    });
};


export  function updateBaseAttr(query){
    return  request({
        url: baseUrl+'/productAttrBase/update',
        method: 'get',
        params: query
    });
};


export  function getSaleAttr(query){
    return  request({
        url: baseUrl+'/productAttrSale/info',
        method: 'get',
        params: query
    });
};

export  function getSaleAttrValue(query){
    return  request({
        url: baseUrl+'/productAttrSaleValue/info',
        method: 'get',
        params: query
    });
};
