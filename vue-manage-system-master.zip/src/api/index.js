import request from '../utils/request';
var baseUrl = "http://127.0.0.1:7001";
export const fetchData = query => {
    return request({
        url: './table.json',
        method: 'get',
        params: query
    });
};

export  function getProviceList(){
     return  request({
        url: baseUrl+'/area/getProviceList',
        method: 'get',
    });
};
export  function  getCityList(id){
    return  request({
        url: baseUrl+'/area/getCityList',
        method: 'get',
        params: {id:id}
    });
};
export  function getAreaList(id){
    return  request({
        url: baseUrl+'/area/getAreaList',
        method: 'get',
        params: {id:id}
    });
};

export  function getBrandByPage(query){
    return  request({
        url: baseUrl+'/brand/findByPage',
        method: 'get',
        params: query
    });
};

export  function addBrand(record){
    return  request({
        url: baseUrl+'/brand/add',
        method: 'get',
        params: record
    });
};

export  function getCategoryByPage(query){
    return  request({
        url: baseUrl+'/category/findByPage',
        method: 'get',
        params: query
    });
};

export  function getSkuByPage(query){
    return  request({
        url: baseUrl+'/productSku/findByPage',
        method: 'get',
        params: query
    });
};

export  function getCategoryTree(query){
    return  request({
        url: baseUrl+'/category/findByTree',
        method: 'get',
        params: query
    });
};

export  function getCategoryInfo(query){
    return  request({
        url: baseUrl+'/category/info',
        method: 'get',
        params: query
    });
};
