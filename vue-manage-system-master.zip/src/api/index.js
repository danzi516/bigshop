import request from '../utils/request';

export const fetchData = query => {
    return request({
        url: './table.json',
        method: 'get',
        params: query
    });
};

export  function getProviceList(){
     return  request({
        url: 'http://127.0.0.1:7001/area/getProviceList',
        method: 'get',
    });
};
export  function  getCityList(id){
    return  request({
        url: 'http://127.0.0.1:7001/area/getCityList',
        method: 'get',
        params: {id:id}
    });
};
export  function getAreaList(id){
    return  request({
        url: 'http://127.0.0.1:7001/area/getAreaList',
        method: 'get',
        params: {id:id}
    });
};
