<!---员工管理--->
<template>
  <div>
    <el-row>
      <el-col :span="3">
        <el-table :data="tabelData" border style="width: 100%" :highlight-current-row="false">
          <el-table-column prop="" align="center" label="岗位员工">
            <template slot-scope="scope">
              <ul>
                <li align="left">
                  <span class="pointer pad-lf10 hei30" :class="{ active: selectActive==-1 }" @click="changeEmployeeType(-1)"> 全部员工</span>
                </li>
                <li align="left" v-for="(item,index) in employeeTypeLists" :key="item.position">
                  <span class="pointer pad-lf30 hei30" :class="{ active: selectActive==item }" @click="changeEmployeeType(index,item)"> {{item.posName}}（{{item.num}}）</span>
                </li>
              </ul>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
      <el-col :span="21" class="pad-lf10">
        <el-table :data="employeeList" border>
          <el-table-column prop="nickName" label="昵称" align="center">
            <template slot-scope="scope">
              <div>
                <div v-if="(0==scope.$index || 1==scope.row.handleType)&&selectActive==-1">
                  <el-input v-model="scope.row.nickName" size="mini"></el-input>
                </div>
                <div v-else>
                  {{scope.row.nickName}}
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="staffName" label="姓名*" align="center">
            <template slot-scope="scope">
              <div>
                <div v-if="(0==scope.$index || 1==scope.row.handleType)&&selectActive==-1">
                  <el-input v-model="scope.row.staffName" size="mini"></el-input>
                </div>
                <div v-else>
                  {{scope.row.staffName}}
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="bindPhone" label="账号（手机号）*" align="center">
            <template slot-scope="scope">
              <div>
                <div v-if="(0==scope.$index || 1==scope.row.handleType)&&selectActive==-1">
                  <el-input v-model="scope.row.bindPhone" size="mini"></el-input>
                </div>
                <div v-else>
                  {{scope.row.bindPhone}}
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="position" label="岗位" align="center" v-if="selectActive==-1" width="500">
            <template slot-scope="scope">
              <div>
                <div v-if="(0==scope.$index&&selectActive==-1) || 1==scope.row.handleType">
                  <el-checkbox-group v-model="scope.row.positionIds" size="mini">
                    <el-checkbox v-for="(val,key) in employeeTypeLists" :key="key" :label="val.position">{{val.posName}}</el-checkbox>
                  </el-checkbox-group>
                </div>
                <div v-else>
                  {{scope.row.positionNames}}
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="area" label="负责客户区域" key="area" align="center" v-if="selectActive.position==18">
            <template slot-scope="scope">
              <div>
                <div v-if="1==scope.row.handleType">
                  <div>
                    <el-tag class="mar-r10 mar-top5" type="primary" closable size="mini" v-for="re in areaSelectList" :key="re.id" @close="handleClear(re)">{{re.name}}</el-tag>
                    <i slot="suffix" class="el-input__icon el-icon-caret-bottom fr" @click="choseArea"></i>
                  </div>
                </div>
                <div v-else>
                  {{scope.row.areaListNames}}
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="depCode" label="大小掌柜发展码" key="depCode" align="center" v-if="selectActive.position==18">
            <template slot-scope="scope">
              <div>
                <!-- <div v-if="1==scope.row.handleType">
                  <el-input v-model="scope.row.depCode" size="mini"></el-input>
                </div>
                <div v-else> -->
                <div>
                  <span>发展码:{{ scope.row.bindPhone }}</span></div>
                <div>
                  <el-button type="info" size="mini" @click="shareInvite(scope.row)">分享注册邀请</el-button>
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="area2" label="负责区县" key="area2" align="center" v-if="selectActive.position==3">
            <template slot-scope="scope">
              <div>
                <div v-if="1==scope.row.handleType">
                  <div>
                    <el-tag class="mar-r10 mar-top5" type="primary" closable size="mini" v-for="re in areaSelectList" :key="re.id" @close="handleClear(re)">{{re.name}}</el-tag>
                    <i slot="suffix" class="el-input__icon el-icon-caret-bottom fr" @click="choseArea"></i>
                  </div>
                </div>
                <div v-else>
                  {{scope.row.areaListNames}}
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="pstaffName" label="默认对口采购员" key="pstaffName" align="center" v-if="selectActive.position==3">
            <template slot-scope="scope">
              <div>
                <div v-if="1==scope.row.handleType">
                  <el-select v-model="scope.row.purEmpId" placeholder="请选择" size="mini">
                    <el-option v-for="item in purLists" :key="item.empId" :label="item.staffName+' — '+item.bindPhone" :value="item.empId">
                    </el-option>
                  </el-select>
                </div>
                <div v-else>
                  {{scope.row.pstaffName}}——{{scope.row.pbindPhone}}
                </div>
              </div>
            </template>
          </el-table-column>
          <!-- <el-table-column prop="tag" label="负责商家标签" key="tag" align="center" v-if="selectActive.position==5">
            <template slot-scope="scope">
              <div>
                <div v-if="1==scope.row.handleType">
                  <el-input v-model="scope.row.tag" size="mini" suffix-icon="el-icon-caret-bottom"></el-input>
                </div>
                <div v-else>
                  {{scope.row.tag}}
                </div>
              </div>
            </template>
          </el-table-column> -->
          <el-table-column prop="opration" label="操作" align="center" v-if="selectActive.position==18 || selectActive.position==3  || selectActive==-1">
            <template slot-scope="scope">
              <div v-if="0==scope.$index&&selectActive==-1">
                <el-button :loading="scope.row.saveLoading" type="text" @click="onSave(scope.row)">新增</el-button>
              </div>
              <div v-else-if="1==scope.row.handleType">
                <el-button :loading="scope.row.saveLoading" @click="onSave(scope.row)" type="text">保存</el-button>
                <el-button @click="onCancel(scope.row)" type="text">取消</el-button>
              </div>
              <div v-else>
                <el-button @click="onEdit(scope.row)" type="text">编辑</el-button>
                <span v-if="selectActive==-1">
                  <el-button v-if="scope.row.status==0" @click="onFreez(scope.row)" type="text">冻结</el-button>
                  <el-button v-if="scope.row.status==1" @click="onUnfreez(scope.row)" type="text">解冻</el-button>
                  <el-button @click="onChangePassword(scope.row)" type="text">设置密码</el-button>
                  <!-- <el-button @click="onChatRec(scope.row)" type="text">聊天记录</el-button> -->
                </span>
              </div>
            </template>
          </el-table-column>
        </el-table>
      </el-col>
    </el-row>
    <el-dialog title="设置密码" :visible.sync="changePassDialog" width="400px">
      <el-row>
        <el-col>
          <span class="hei30">请输入{{changePassName}}的密码：</span>
          <el-input v-model="password" size="mini"></el-input>
          <div class="fr mar-top30">
            <el-button type="primary" @click="onSavePass()" size="mini">确定</el-button>
            <el-button type="primary" @click="onCancelPass()" size="mini">取消</el-button>
          </div>
        </el-col>
      </el-row>
    </el-dialog>
    <el-dialog title="选择区域" :visible.sync="choseAreaDialog" width="600px">
      <el-row>
        <el-col>
          <wareaselect ref="wareaselect" :type=3 :initData="areaList"></wareaselect>
          <div class="fr mar-top30">
            <el-button type="primary" @click="onSaveArea()" size="mini">确定</el-button>
            <el-button type="primary" @click="onCancelArea()" size="mini">取消</el-button>
          </div>
        </el-col>
      </el-row>
    </el-dialog>
    <shareDailog ref="shareDailog"></shareDailog>
  </div>
</template>
<script>
import wgridview from 'common_plugin/src/plugins/WGridView';
import wareaselect from 'common_plugin/src/plugins/WAreaSelect';
import shareDailog from '@/components/Tools/common/shareDailog';
import im from '@/components/Tools/common/im';
export default {
  name: 'employeeManager',
  components: {
    wgridview,
    wareaselect,
    shareDailog
  },
  mixins: [im],
  data() {
    return {
      tabelData: [{}],
      employeeList: [],
      searchData: {},
      selectActive: -1,
      employeeTypeLists: [],
      changePassDialog: false,
      password: '',
      changePassId: '',
      changePassName: '',
      url: '',
      // totalNum: '',
      choseAreaDialog: false,
      areaSelectList: [],
      areaList: [],
      purLists: []
    };
  },
  computed: {},
  watch: {},
  methods: {
    //获取员工
    getEmployee() {
      if (this.selectActive == -1) {
        //全部员工
        this.url = 'oum301';
      } else if (this.selectActive.position == 6) {
        //财务员工
        this.url = 'emps005';
      } else if (this.selectActive.position == 18) {
        //客户经理
        this.url = 'emps006';
      } else if (this.selectActive.position == 5) {
        //采购员
        this.url = 'emps007';
      } else if (this.selectActive.position == 3) {
        //销售员
        this.url = 'emps008';
        this.getPurList();
      } else if (this.selectActive.position == 19) {
        //私联宝管理员
        this.url = 'emps009';
      }
      this.$api.mmlSyj[this.url]()
        .then(response => {
          if (response.data.header.code == 200) {
            if (this.selectActive == -1) {
              this.employeeList = response.data.body.result.employeeList;
              this.employeeList.unshift({
                nickName: '',
                staffName: '',
                bindPhone: '',
                position: '',
                positionIds: [],
                area: '',
                depCode: '',
                area2: '',
                pstaffName: '',
                tag: ''
              });
            } else {
              this.employeeList = response.data.body.result.list;
              if (
                this.selectActive.position == 18 ||
                this.selectActive.position == 3
              ) {
                this.employeeList.forEach(val => {
                  let nameArray = [];
                  val.areaList.forEach(v => {
                    nameArray.push(v.areaName);
                  });
                  val.areaListNames = nameArray.join(',');
                });
              }
            }
          } else {
            this.$alert(response.data.body.retMsg || '获取员工失败');
          }
        })
        .finally(() => { });
    },
    //获取岗位
    getEmployeeType() {
      this.$api.mmlSyj
        .emps001()
        .then(response => {
          if (response.data.header.code == 200) {
            this.employeeTypeLists = response.data.body.result.list;
            // this.totalNum = this.employeeTypeLists.reduce(
            //   (total, cv) => total + cv.num,
            //   0
            // );
          } else {
            this.$alert(response.data.body.retMsg || '获取岗位失败');
          }
        })
        .finally(() => { });
    },
    //获取采购员列表
    getPurList() {
      this.$api.mmlSyj
        .emps007()
        .then(response => {
          if (response.data.header.code == 200) {
            this.purLists = response.data.body.result.list;
          } else {
            this.$alert(response.data.body.retMsg || '获取失败');
          }
        })
        .finally(() => { });
    },
    //切换岗位
    changeEmployeeType(index, item) {
      if (index == -1) {
        this.selectActive = -1;
      } else {
        this.selectActive = item;
      }
      this.getEmployee();
    },
    submit() {
      this.getEmployeeType();
      this.getEmployee();
    },
    //保存
    onSave(row) {
      if (this.selectActive == -1) {
        if (!row.nickName) {
          this.$message.error('昵称不能为空');
          return;
        }
        if (!row.staffName) {
          this.$message.error('姓名不能为空');
          return;
        }
        if (!row.bindPhone) {
          this.$message.error('账号不能为空');
          return;
        }
        let telReg = /^1\d{10}$/;
        if (!telReg.test(row.bindPhone)) {
          this.$message.error("请输入1开头的11位手机号");
          return false;
        }
        if (row.positionIds.length < 1) {
          this.$message.error('岗位必选');
          return;
        }
        if (row.positionIds.length > 0) {
          row.position = row.positionIds.join(',');
        }
        if (!row.saveLoading) {
          row.saveLoading = true;
          let param = {
            employeeId: row.id || null,
            staffName: row.staffName,
            bindPhone: row.bindPhone,
            nickName: row.nickName,
            position: row.position || null
          };
          let url = '';
          if (row.id) {
            url = 'oum304'
          } else {
            url = 'oum303'
          }
          this.$api.mmlSyj[url](param)
            .then(response => {
              if (response.data.header.code == 200) {
                if (row.id) {
                  this.$message.success('保存成功');
                  row.handleType = 0;
                } else {
                  this.$message.success('新增成功');
                }
                this.submit();
              } else {
                if (row.id) {
                  this.$alert(response.data.body.retMsg || '保存失败');
                } else {
                  this.$alert(response.data.body.retMsg || '新增失败');
                }
              }
            })
            .finally(() => {
              row.saveLoading = false;
            });
        }
      } else {
        let saveUrl = '';
        let param = {};
        let arealistData = [];
        if (this.areaSelectList.length < 1) {
          this.$message.error('区域必选');
          return;
        }
        this.areaSelectList.forEach(v => {
          arealistData.push({
            province: v.ProvinceId,
            city: v.CityId,
            district: v.value,
            areaName: v.name
          });
        });
        if (this.selectActive.position == 18) {
          //保存客户经理特征设置
          param = {
            empId: row.empId || null,
            areaList: arealistData
          };
          saveUrl = 'emps010';
        } else if (this.selectActive.position == 3) {
          //保存销售员特征设置
          param = {
            empId: row.empId || null,
            areaList: arealistData,
            purEmpId: row.purEmpId
          };
          saveUrl = 'emps011';
        }
        if (!row.saveLoading) {
          row.saveLoading = true;
          this.$api.mmlSyj[saveUrl](param)
            .then(response => {
              if (response.data.header.code == 200) {
                this.$message.success('保存成功');
                row.handleType = 0;
                this.getEmployee();
              } else {
                this.$alert(response.data.body.retMsg || '保存失败');
              }
            })
            .finally(() => {
              row.saveLoading = false;
            });
        }
      }
    },
    //编辑
    onEdit(row) {
      row.oldData = JSON.parse(JSON.stringify(row));
      this.employeeList.forEach(val => {
        this.$set(val, 'handleType', 0);
      });
      this.$set(row, 'handleType', 1);
      if (this.selectActive == -1) {
        this.$set(row, 'positionIds', []);
        row.positionIds = row.position.split(',');
        row.positionIds = row.positionIds.map(value => {
          return parseInt(value);
        });
      } else {
        this.areaSelectList = [];
        row.areaList.forEach(v => {
          this.areaSelectList.push({
            ProvinceId: v.province,
            CityId: v.city,
            value: v.district,
            name: v.areaName,
            label: v.areaName,
            id: v.district,
            parentID: v.city,
            shortName: v.areaName
          });
        });
      }
    },
    //取消
    onCancel(row) {
      Object.assign(row, row.oldData);
      row.handleType = 0;
    },
    //冻结
    onFreez(row) {
      this.$api.mmlSyj
        .oum312({ employeeId: row.id })
        .then(response => {
          if (response.data.header.code == 200) {
            this.$message.success('处理成功');
            row.status = 1;
          } else {
            this.$alert(response.data.body.retMsg || '处理失败');
          }
        })
        .finally(() => { });
    },
    //解冻
    onUnfreez(row) {
      this.$api.mmlSyj
        .oum313({ employeeId: row.id })
        .then(response => {
          if (response.data.header.code == 200) {
            this.$message.success('处理成功');
            row.status = 0;
          } else {
            this.$alert(response.data.body.retMsg || '处理失败');
          }
        })
        .finally(() => { });
    },
    //修改密码弹框
    onChangePassword(row) {
      this.changePassDialog = true;
      this.changePassId = row.id;
      this.changePassName = row.staffName;
    },
    //保存修改密码
    onSavePass() {
      this.$api.mmlSyj
        .oum337({ employeeId: this.changePassId, passWord: this.password })
        .then(response => {
          if (response.data.header.code == 200) {
            this.$message.success('处理成功');
            this.changePassDialog = false;
            this.resetPassData();
          } else {
            this.$alert(response.data.body.retMsg || '处理失败');
          }
        })
        .finally(() => { });
    },
    //取消修改密码
    onCancelPass() {
      this.changePassDialog = false;
      this.resetPassData();
    },
    //重置修改密码数据
    resetPassData() {
      this.changePassId = '';
      this.changePassName = '';
      this.password = '';
    },
    //选择区域弹框
    choseArea() {
      this.areaList = this.json(this.areaSelectList);
      this.choseAreaDialog = true;
    },
    // 清除选择
    handleClear(re) {
      this.areaSelectList = this.areaSelectList.filter(item => {
        return item.id != re.id;
      });
    },
    //选择区域
    onSaveArea() {
      this.areaSelectList = this.$refs.wareaselect.getReulst();
      // this.areaSelectList = this.json(this.areaList);
      this.choseAreaDialog = false;
    },
    //取消选择区域
    onCancelArea() {
      this.areaList = [];
      this.choseAreaDialog = false;
    },
    //分享注册链接
    shareInvite(row) {
      this.$refs.shareDailog.openShareDg(row);
    },
    //聊天记录
    onChatRec(row) {
      let roomID = this.getRoomID(row.organId, row.userId);
      let time = (new Date().getTime() / 1000).formateDate('yyyy-MM-dd');
      let params = {
        roomId: roomID,
        date: time,
        title: row.staffName || row.nickName
      };
      this.clientJs.lookOverChrttingRecords(params);
    },
    //获取房间号
    getRoomID(recvOID, recvUID) {
      let unionID = null;
      let organID = recvOID;
      let userID = recvUID;
      let roomID = this.createRoomID(
        {
          organID: organID,
          userID: userID
        },
        {
          userID: this.headerInfo.userId,
          organID: this.headerInfo.organId
        },
        unionID
      );
      return roomID;
    },
  },
  mounted() { },
  activated() {
    this.submit();
  }
};
</script>
<style>
.el-table--enable-row-hover .el-table__body tr:hover > td {
  background-color: transparent !important;
}
.active {
  color: #20a0ff;
}
</style>