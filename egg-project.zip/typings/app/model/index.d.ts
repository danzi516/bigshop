// This file is created by egg-ts-helper@1.25.7
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportArea = require('../../../app/model/area');
import ExportBrand = require('../../../app/model/brand');
import ExportBrandCategory = require('../../../app/model/brandCategory');
import ExportCategory = require('../../../app/model/category');
import ExportCategoryP = require('../../../app/model/categoryP');
import ExportLevel = require('../../../app/model/level');
import ExportOrgan = require('../../../app/model/organ');
import ExportOrganCustomer = require('../../../app/model/organCustomer');
import ExportOrganEmployee = require('../../../app/model/organEmployee');
import ExportOrganMember = require('../../../app/model/organMember');
import ExportProductAttr = require('../../../app/model/productAttr');
import ExportProductAttrValue = require('../../../app/model/productAttrValue');
import ExportProductSku = require('../../../app/model/productSku');
import ExportProductSkuExt = require('../../../app/model/productSkuExt');
import ExportProductSpu = require('../../../app/model/productSpu');
import ExportProductSpuSkuAttrMap = require('../../../app/model/productSpuSkuAttrMap');
import ExportShopCart = require('../../../app/model/shopCart');
import ExportUser = require('../../../app/model/user');

declare module 'egg' {
  interface IModel {
    Area: ReturnType<typeof ExportArea>;
    Brand: ReturnType<typeof ExportBrand>;
    BrandCategory: ReturnType<typeof ExportBrandCategory>;
    Category: ReturnType<typeof ExportCategory>;
    CategoryP: ReturnType<typeof ExportCategoryP>;
    Level: ReturnType<typeof ExportLevel>;
    Organ: ReturnType<typeof ExportOrgan>;
    OrganCustomer: ReturnType<typeof ExportOrganCustomer>;
    OrganEmployee: ReturnType<typeof ExportOrganEmployee>;
    OrganMember: ReturnType<typeof ExportOrganMember>;
    ProductAttr: ReturnType<typeof ExportProductAttr>;
    ProductAttrValue: ReturnType<typeof ExportProductAttrValue>;
    ProductSku: ReturnType<typeof ExportProductSku>;
    ProductSkuExt: ReturnType<typeof ExportProductSkuExt>;
    ProductSpu: ReturnType<typeof ExportProductSpu>;
    ProductSpuSkuAttrMap: ReturnType<typeof ExportProductSpuSkuAttrMap>;
    ShopCart: ReturnType<typeof ExportShopCart>;
    User: ReturnType<typeof ExportUser>;
  }
}
