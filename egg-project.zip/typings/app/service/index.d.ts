// This file is created by egg-ts-helper@1.25.7
// Do not modify this file!!!!!!!!!

import 'egg';
type AnyClass = new (...args: any[]) => any;
type AnyFunc<T = any> = (...args: any[]) => T;
type CanExportFunc = AnyFunc<Promise<any>> | AnyFunc<IterableIterator<any>>;
type AutoInstanceType<T, U = T extends CanExportFunc ? T : T extends AnyFunc ? ReturnType<T> : T> = U extends AnyClass ? InstanceType<U> : U;
import ExportArea = require('../../../app/service/area');
import ExportBrand = require('../../../app/service/brand');
import ExportBrandCategory = require('../../../app/service/brandCategory');
import ExportCategory = require('../../../app/service/category');
import ExportLevel = require('../../../app/service/level');
import ExportOrgan = require('../../../app/service/organ');
import ExportOrganCustomer = require('../../../app/service/organCustomer');
import ExportOrganMember = require('../../../app/service/organMember');
import ExportPrintShop = require('../../../app/service/printShop');
import ExportProductAttr = require('../../../app/service/productAttr');
import ExportProductAttrValue = require('../../../app/service/productAttrValue');
import ExportProductSku = require('../../../app/service/productSku');
import ExportProductSkuExt = require('../../../app/service/productSkuExt');
import ExportProductSpu = require('../../../app/service/productSpu');
import ExportProductSpuSkuAttrMap = require('../../../app/service/productSpuSkuAttrMap');
import ExportShopCart = require('../../../app/service/shopCart');
import ExportUser = require('../../../app/service/user');

declare module 'egg' {
  interface IService {
    area: AutoInstanceType<typeof ExportArea>;
    brand: AutoInstanceType<typeof ExportBrand>;
    brandCategory: AutoInstanceType<typeof ExportBrandCategory>;
    category: AutoInstanceType<typeof ExportCategory>;
    level: AutoInstanceType<typeof ExportLevel>;
    organ: AutoInstanceType<typeof ExportOrgan>;
    organCustomer: AutoInstanceType<typeof ExportOrganCustomer>;
    organMember: AutoInstanceType<typeof ExportOrganMember>;
    printShop: AutoInstanceType<typeof ExportPrintShop>;
    productAttr: AutoInstanceType<typeof ExportProductAttr>;
    productAttrValue: AutoInstanceType<typeof ExportProductAttrValue>;
    productSku: AutoInstanceType<typeof ExportProductSku>;
    productSkuExt: AutoInstanceType<typeof ExportProductSkuExt>;
    productSpu: AutoInstanceType<typeof ExportProductSpu>;
    productSpuSkuAttrMap: AutoInstanceType<typeof ExportProductSpuSkuAttrMap>;
    shopCart: AutoInstanceType<typeof ExportShopCart>;
    user: AutoInstanceType<typeof ExportUser>;
  }
}
