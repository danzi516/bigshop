// This file is created by egg-ts-helper@1.25.7
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportArea = require('../../../app/controller/area');
import ExportBrand = require('../../../app/controller/brand');
import ExportBrandCategory = require('../../../app/controller/brandCategory');
import ExportCategory = require('../../../app/controller/category');
import ExportLevel = require('../../../app/controller/level');
import ExportOrgan = require('../../../app/controller/organ');
import ExportOrganCustomer = require('../../../app/controller/organCustomer');
import ExportOrganMember = require('../../../app/controller/organMember');
import ExportPrintShop = require('../../../app/controller/printShop');
import ExportProductAttr = require('../../../app/controller/productAttr');
import ExportProductAttrValue = require('../../../app/controller/productAttrValue');
import ExportProductSku = require('../../../app/controller/productSku');
import ExportProductSkuExt = require('../../../app/controller/productSkuExt');
import ExportProductSpu = require('../../../app/controller/productSpu');
import ExportProductSpuSkuAttrMap = require('../../../app/controller/productSpuSkuAttrMap');
import ExportShopCart = require('../../../app/controller/shopCart');
import ExportUser = require('../../../app/controller/user');

declare module 'egg' {
  interface IController {
    area: ExportArea;
    brand: ExportBrand;
    brandCategory: ExportBrandCategory;
    category: ExportCategory;
    level: ExportLevel;
    organ: ExportOrgan;
    organCustomer: ExportOrganCustomer;
    organMember: ExportOrganMember;
    printShop: ExportPrintShop;
    productAttr: ExportProductAttr;
    productAttrValue: ExportProductAttrValue;
    productSku: ExportProductSku;
    productSkuExt: ExportProductSkuExt;
    productSpu: ExportProductSpu;
    productSpuSkuAttrMap: ExportProductSpuSkuAttrMap;
    shopCart: ExportShopCart;
    user: ExportUser;
  }
}
