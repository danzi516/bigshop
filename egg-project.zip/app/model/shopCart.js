module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const ShopCart = app.model.define('shopCart', {
      id: { type: INTEGER, primaryKey: true ,autoIncrement: true,field:'id' },
      userId:{type:INTEGER,field: 'userId'},
      skuId:{type:INTEGER,field: 'skuId'},
      count:{type:STRING(30),field: 'count'},
      creatTime:{type:STRING(30),field: 'creatTime'},
    },{tableName:'shop_cart'});
    ShopCart.associate  = function(){
      app.model.ShopCart.belongsTo(app.model.User, {foreignKey: 'userId',targetKey:'id'});
      app.model.ShopCart.belongsTo(app.model.ProductSku, {foreignKey: 'skuId',targetKey:'id'});
  }
    return ShopCart;
  }