module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const Organ = app.model.define('organ', {
      id: { type: INTEGER, primaryKey: true },
      name: {type:STRING(30),field: 'name'},
      bossPhone:{type:STRING(30),field: 'bossPhone'},
      bossName:{type:STRING(30),field: 'bossName'},
	  weixinQRcode:{type:STRING(30),field: 'weixinQRcode'},
      desc:{type:STRING(30),field: 'desc'},
	  address:{type:STRING(30),field: 'address'}
    },{tableName:'organ'});
 
    return Organ;
  }