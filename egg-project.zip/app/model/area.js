module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const area = app.model.define('area_trade', {
      id: { type: INTEGER, primaryKey: true ,autoIncrement: true,field:'id' },
      Language:{type:STRING(30),field: 'Language'},
      ParentID:{type:INTEGER,field: 'ParentID'},
      Path:{type:STRING(30),field: 'Path'},
      Grade:{type:STRING(30),field: 'Grade'},
	  TradeType:{type:INTEGER,field: 'TradeType'},
	  Name:{type:STRING(30),field: 'Name'},
	  ShortName:{type:STRING(30),field: 'ShortName'},
	FullName:{type:STRING(30),field: 'FullName'},
	AreaCode:{type:STRING(30),field: 'AreaCode'},
    },{tableName:'area_trade'});
    
    return area;
  }