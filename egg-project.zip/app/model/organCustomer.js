module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const OrganCustomer = app.model.define('organCustomer', {
      id: { type: INTEGER, primaryKey: true ,autoIncrement: true,field:'id' },
      userId:{type:STRING(30),field: 'userId'},
      linkName:{type:STRING(30),field: 'linkName'},
      linkPhone:{type:STRING(30),field: 'linkPhone'},
      address:{type:STRING(30),field: 'address'},
      province:{type:STRING(30),field: 'province'},
      pcode:{type:STRING(30),field: 'pcode'},
      city:{type:STRING(30),field: 'city'},
      ccode:{type:STRING(30),field: 'ccode'},
      area:{type:STRING(30),field: 'area'},
      acode:{type:STRING(30),field: 'acode'},
      creatTime:{type:STRING(30),field: 'creatTime'},
      orgId:{type:INTEGER,field: 'orgId'},
    },{tableName:'organ_customer'});
    
    return OrganCustomer;
  }