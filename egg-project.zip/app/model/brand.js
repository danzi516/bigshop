module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const Brand = app.model.define('brand', {
      id: { type: INTEGER, primaryKey: true },
      pid: {type:INTEGER,field: 'pid'},
      name:{type:STRING(30),field: 'name'},
      creatAt:{type:STRING(30),field: 'creatAt'},
      creatBy:{type:STRING(30),field: 'creatBy'},
      updateAt:{type:STRING(30),field: 'updateAt'},
      updateBy:{type:STRING(30),field: 'updateBy'},
      state:{type:STRING(30),field: 'state'},
      level:{type:STRING(30),field: 'level'},
      isTrue:{type:STRING(30),field: 'isTrue'},
      isEnd:{type:STRING(30),field: 'isEnd'},
      pyf:{type:STRING(30),field: 'pyf'},
      logoUrl:{type:STRING(30),field: 'logoUrl'},
      desc:{type:STRING(30),field: 'desc'},
    },{tableName:'product_brand'});
 
    return Brand;
  }