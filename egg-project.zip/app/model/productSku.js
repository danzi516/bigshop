module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const ProductSku = app.model.define('sku', {
      id: { type: INTEGER, primaryKey: true ,autoIncrement: true,field:'id' },
      name:{type:STRING(30),field: 'name'},
      desc:{type:STRING(30),field: 'desc'},
      sellingPoint:{type:STRING(30),field: 'sellingPoint'},
      bannerUrl:{type:STRING(30),field: 'bannerUrl'},
      unit:{type:STRING(30),field: 'unit'},
      mainUrl:{type:STRING(30),field: 'mainUrl'},
      detailUrl:{type:STRING(30),field: 'detailUrl'},
      priceFee:{type:STRING(30),field: 'priceFee'},
      marketPriceFee:{type:STRING(30),field: 'marketPriceFee'},
      state:{type:STRING(30),field: 'state'},
      brandId:{type:STRING(30),field: 'brandId'},
      categoryId:{type:STRING(30),field: 'categoryId'},
      spuId:{type:STRING(30),field: 'spuId'},
      saleUnit:{type:STRING(30),field: 'saleUnit'},
      saleUnitRate:{type:STRING(30),field: 'saleUnitRate'},
      sellOID:{type:INTEGER,field: 'sellOID'},
      sellOrg:{type:STRING(30),field: 'sellOrg'},
      sellUID:{type:INTEGER,field: 'sellUID'},
      sellName:{type:STRING(30),field: 'sellName'},
      saleType:{type:STRING(30),field: 'saleType'},
    },{tableName:'product_sku'});
    ProductSku.associate  = function(){
      app.model.ProductSku.belongsTo(app.model.Category, {foreignKey: 'categoryId',targetKey:'id'});
      app.model.ProductSku.belongsTo(app.model.Brand, {foreignKey: 'brandId',targetKey:'id'});
      app.model.ProductSku.belongsTo(app.model.ProductSpu, {foreignKey: 'spuId',targetKey:'id'});
      app.model.ProductSku.hasMany(app.model.ProductSkuExt, {foreignKey: 'skuId'});
	  app.model.ProductSku.hasMany(app.model.ProductAttrBase, {foreignKey: 'skuId'});
  }
    return ProductSku;
  }