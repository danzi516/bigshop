module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const UnionOrgan = app.model.define('UnionOrgan', {
      id: { type: INTEGER, primaryKey: true ,autoIncrement: true,field:'id' },
      unionId:{type:INTEGER,field: 'unionId'},
      orgId:{type:INTEGER,field: 'orgId'},
	  creatAt:{type:INTEGER,field: 'creatAt'},
    },{tableName:'union_organ'});
       UnionOrgan.associate  = function(){
      app.model.UnionOrgan.belongsTo(app.model.Union, {foreignKey: 'unionId',targetKey:'id'});
      app.model.UnionOrgan.belongsTo(app.model.Organ, {foreignKey: 'orgId',targetKey:'id'});
  }
    return UnionOrgan;
  }