module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const User = app.model.define('user', {
      id: { type: INTEGER, primaryKey: true ,autoIncrement: true,field:'id' },
      name:{type:STRING(30),field: 'name'},
      openId:{type:INTEGER,field: 'openId'},
      unionId:{type:INTEGER,field: 'unionId'},
      phone:{type:STRING(30),field: 'phone'},
      password:{type:STRING(30),field: 'password'},
      isTrue:{type:STRING(30),field: 'isTrue'},
    },{tableName:'user'});

    return User;
  }