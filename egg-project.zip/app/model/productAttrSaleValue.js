module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const ProductAttrSaleValue = app.model.define('ProductAttrSaleValue', {
      id: { type: INTEGER, primaryKey: true },
      attrId: {type:INTEGER,field: 'attrId'},
      name:{type:STRING(30),field: 'name'},
      desc:{type:STRING(30),field: 'desc'},
      status:{type:STRING(30),field: 'status'},
	  price: {type:STRING(30),field: 'price'},
	  skuId: {type:INTEGER,field: 'skuId'},
    },{tableName:'product_attr_sale_value'});
    ProductAttrSaleValue.associate  = function(){
        app.model.ProductAttrSaleValue.belongsTo(app.model.ProductAttrSale, {foreignKey: 'attrId',targetKey:'id'});
		
    }
    return ProductAttrSaleValue;
  }