module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const OrganMember = app.model.define('organ_member', {
      id: { type: INTEGER, primaryKey: true ,autoIncrement: true,field:'id' },
      orgId:{type:INTEGER,field: 'orgId'},
      userId:{type:INTEGER,field: 'userId'},
      saleRate:{type:STRING(30),field: 'sale_rate'},
      levelId:{type:INTEGER,field: 'levelId'},
    },{tableName:'organ_member'});
    
    OrganMember.associate  = function(){
        app.model.OrganMember.belongsTo(app.model.Organ, {foreignKey: 'orgId',targetKey:'id'});
        app.model.OrganMember.belongsTo(app.model.User, {foreignKey: 'userId',targetKey:'id'});
        app.model.OrganMember.belongsTo(app.model.Level, {foreignKey: 'levelId',targetKey:'id'});
  }

    return OrganMember;
  }