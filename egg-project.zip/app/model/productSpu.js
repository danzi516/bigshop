module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const ProductSpu = app.model.define('spu', {
      id: { type: INTEGER, primaryKey: true ,autoIncrement: true,field:'id' },
      name:{type:STRING(30),field: 'name'},
      desc:{type:STRING(30),field: 'desc'},
      sellingPoint:{type:STRING(30),field: 'sellingPoint'},
      bannerUrl:{type:STRING(30),field: 'bannerUrl'},
      unit:{type:STRING(30),field: 'unit'},
      mainUrl:{type:STRING(30),field: 'mainUrl'},
      detailUrl:{type:STRING(30),field: 'detailUrl'},
      priceFee:{type:STRING(30),field: 'priceFee'},
      marketPriceFee:{type:STRING(30),field: 'marketPriceFee'},
      state:{type:STRING(30),field: 'state'},
      brandId:{type:STRING(30),field: 'brandId'},
      categoryId:{type:STRING(30),field: 'categoryId'},
      spec:{type:STRING(30),field: 'spec'},
    },{tableName:'product_spu'});
    ProductSpu.associate  = function(){
      app.model.ProductSpu.belongsTo(app.model.Category, {foreignKey: 'categoryId',targetKey:'id'});
      app.model.ProductSpu.belongsTo(app.model.Brand, {foreignKey: 'brandId',targetKey:'id'});
  }
    return ProductSpu;
  }