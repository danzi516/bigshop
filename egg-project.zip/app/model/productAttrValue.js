module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const ProductAttrValue = app.model.define('productAttrValue', {
      id: { type: INTEGER, primaryKey: true },
      attrId: {type:INTEGER,field: 'attrId'},
      value:{type:STRING(30),field: 'value'},
      desc:{type:STRING(30),field: 'desc'},
      status:{type:STRING(30),field: 'status'},
    },{tableName:'product_attr_value'});
    ProductAttrValue.associate  = function(){
        app.model.ProductAttrValue.belongsTo(app.model.ProductAttr, {foreignKey: 'attrId',targetKey:'id'});
    }
    return ProductAttrValue;
  }