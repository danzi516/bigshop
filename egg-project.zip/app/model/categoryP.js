module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const CategoryP = app.model.define('categoryP', {
      id: { type: INTEGER, primaryKey: true },
      pid: {type:INTEGER,field: 'pid'},
      name:{type:STRING(30),field: 'name'},
      creatAt:{type:STRING(30),field: 'creatAt'},
      creatBy:{type:STRING(30),field: 'creatBy'},
      updateAt:{type:STRING(30),field: 'updateAt'},
      updateBy:{type:STRING(30),field: 'updateBy'},
      state:{type:STRING(30),field: 'state'},
      level:{type:STRING(30),field: 'level'},
      isEnd:{type:STRING(30),field: 'isEnd'},
    },{tableName:'product_category'});

    return CategoryP;
  }