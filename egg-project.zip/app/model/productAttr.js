module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const ProductAttr = app.model.define('productAttr', {
      id: { type: INTEGER, primaryKey: true },
      name:{type:STRING(30),field: 'name'},
      desc:{type:STRING(30),field: 'desc'},
      status:{type:STRING(30),field: 'status'},
    },{tableName:'product_attr'});
    ProductAttr.associate  = function(){
        app.model.ProductAttr.hasMany(app.model.ProductAttrValue,{foreignKey:'attrId'});
    }
    return ProductAttr;
  }