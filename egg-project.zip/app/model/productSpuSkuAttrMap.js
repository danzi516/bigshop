module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const ProductSpuSkuAttrMap = app.model.define('productSpuSkuAttr', {
      id: { type: INTEGER, primaryKey: true ,autoIncrement: true,field:'id' },
      spuId:{type:INTEGER,field: 'spuId'},
      skuId:{type:INTEGER,field: 'skuId'},
      attrId:{type:INTEGER,field: 'attrId'},
      attrName:{type:STRING(30),field: 'attrName'},
      attrValueId:{type:INTEGER,field: 'attrValueId'},
      attrValueName:{type:STRING(30),field: 'attrValueName'},
      status:{type:STRING(30),field: 'status'},
    },{tableName:'product_spu_sku_attr_map'});
    ProductSpuSkuAttrMap.associate  = function(){
      app.model.ProductSpuSkuAttrMap.belongsTo(app.model.ProductAttrSale, {foreignKey: 'attrId',targetKey:'id'});
      app.model.ProductSpuSkuAttrMap.belongsTo(app.model.ProductAttrSaleValue, {foreignKey: 'attrValueId',targetKey:'id'});
      app.model.ProductSpuSkuAttrMap.belongsTo(app.model.ProductSku, {foreignKey: 'skuId',targetKey:'id'});
      app.model.ProductSpuSkuAttrMap.belongsTo(app.model.ProductSpu, {foreignKey: 'spuId',targetKey:'id'});
  }
    return ProductSpuSkuAttrMap;
  }