module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const BrandCategory = app.model.define('brandCategory', {
      id: { type: INTEGER, primaryKey: true ,autoIncrement: true,field: 'id'},
      bid: {type:INTEGER,field: 'bid'},
      cid:{type:INTEGER,field: 'cid'},
    },{tableName:'product_brand_category'}
    );

    BrandCategory.associate  = function(){
      app.model.BrandCategory.belongsTo(app.model.Brand, {foreignKey: 'bid',targetKey:'id'});
      app.model.BrandCategory.belongsTo(app.model.Category, {foreignKey: 'cid',targetKey:'id'});
}
  
    return BrandCategory;
  };