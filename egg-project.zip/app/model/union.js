module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const Union = app.model.define('Union', {
      id: { type: INTEGER, primaryKey: true ,autoIncrement: true,field:'id' },
      name:{type:STRING(30),field: 'name'},
      creatAt:{type:INTEGER,field: 'creatAt'},
      logo:{type:STRING(30),field: 'logo'},
      creatTime:{type:STRING(30),field: 'creatTime'},
      ower:{type:INTEGER,field: 'ower'},
    },{tableName:'union'});
    Union.associate  = function(){
      app.model.Union.belongsTo(app.model.User, {foreignKey: 'creatAt',targetKey:'id'});
      app.model.Union.belongsTo(app.model.Organ, {foreignKey: 'ower',targetKey:'id'});
  }
    return Union;
  }