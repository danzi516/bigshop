module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const UnionOrgan = app.model.define('UnionOrgan', {
      id: { type: INTEGER, primaryKey: true ,autoIncrement: true,field:'id' },
      unionId:{type:INTEGER,field: 'unionId'},
      orgId:{type:INTEGER,field: 'orgId'},
    },{tableName:'union_organ'});
    
    return UnionOrgan;
  }