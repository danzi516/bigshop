module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const ProductAttrSale = app.model.define('productAttrSale', {
      id: { type: INTEGER, primaryKey: true },
      name:{type:STRING(30),field: 'name'},
      desc:{type:STRING(30),field: 'desc'},
      status:{type:STRING(30),field: 'status'},
	  skuId:{type:INTEGER,field: 'skuId'},
    },{tableName:'product_attr_sale'});
    ProductAttrSale.associate  = function(){
        app.model.ProductAttrSale.hasMany(app.model.ProductAttrSaleValue,{foreignKey:'attrId'});
    }
    return ProductAttrSale;
  }