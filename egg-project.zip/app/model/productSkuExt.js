module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const ProductSkuExt = app.model.define('skuExt', {
      id: { type: INTEGER, primaryKey: true ,autoIncrement: true,field:'id' },
      skuId:{type:STRING(30),field: 'skuId'},
      priceFee:{type:STRING(30),field: 'priceFee'},
      state:{type:STRING(30),field: 'state'},
      discountRate:{type:STRING(30),field: 'discountRate'},
      discountState:{type:STRING(30),field: 'discountState'},
      specialFee:{type:STRING(30),field: 'specialFee'},
      wholesaleFee:{type:STRING(30),field: 'wholesaleFee'},
      wholesaleUnit:{type:STRING(30),field: 'wholesaleUnit'},
      saleState:{type:STRING(30),field: 'saleState'},
      attrIndex:{type:STRING(30),field: 'attrIndex'},
      attrValue:{type:STRING(30),field: 'attrValue'},
      attrName:{type:STRING(30),field: 'attrName'},
	  logo:{type:STRING(30),field: 'logo'},
	  stock:{type:STRING(30),field: 'stock'},
	  childProductNo:{type:STRING(30),field: 'childProductNo'},
	  attrList:{type:STRING(30),field: 'attrList'},
    },{tableName:'product_sku_ext'});
    
    return ProductSkuExt;
  }