module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const ProductAttrBase = app.model.define('productAttrBase', {
      id: { type: INTEGER, primaryKey: true,autoIncrement: true },
      name:{type:STRING(30),field: 'name'},
      value:{type:STRING(30),field: 'value'},
      skuId:{type:INTEGER,field: 'skuId'},
    },{tableName:'product_attr_base'});
    ProductAttrBase.associate  = function(){
        app.model.ProductAttrBase.belongsTo(app.model.ProductSku,{foreignKey: 'skuId',targetKey:'id'});
    }
    return ProductAttrBase;
  }