module.exports = app => {
    const { STRING, INTEGER, DATE } = app.Sequelize;
  
    const Level = app.model.define('level', {
      id: { type: INTEGER, primaryKey: true ,autoIncrement: true,field:'id' },
      name:{type:STRING(30),field: 'name'},
      desc:{type:STRING(30),field: 'desc'},
      logo:{type:STRING(30),field: 'logo'},
      level:{type:STRING(30),field: 'level'},
    },{tableName:'Level'});
    
    return Level;
  }