'use strict';
const Controller = require('egg').Controller;

class BrandController extends Controller {
  async add() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.brand.add(ctx.query);
    ctx.body = record;
  }
  async delete() {
    const ctx = this.ctx;
    const id = ctx.request.body.id;
    const record = await ctx.service.brand.delete(id);
    ctx.body = record;
  }
  async update() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.brand.update(body);
    ctx.body = record;
  }
  async info() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.brand.info(ctx.query);
    ctx.body = record;
  }
  async findByPage() {
    const ctx = this.ctx;
    // console.log(ctx.query)
    // const body = ctx.request.body;
    const record = await ctx.service.brand.findByPage(ctx.query);
    ctx.body = record;
  }
    async groupByPyf() {
      const ctx = this.ctx;
      const body = ctx.request.body;
      const record = await ctx.service.brand.groupByPyf(body);
      ctx.body = record;
    }
  }
  
  module.exports = BrandController;