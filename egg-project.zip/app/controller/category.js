'use strict';
const Controller = require('egg').Controller;

class CategoryController extends Controller {
  async add() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.category.add(body);
    ctx.body = record;
  }
  async delete() {
    const ctx = this.ctx;
    const id = ctx.request.body.id;
    const record = await ctx.service.category.delete(id);
    ctx.body = record;
  }
  async update() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.category.update(body);
    ctx.body = record;
  }
  async info() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.brand.info(body);
    ctx.body = record;
  }
  async findByTree() {
    const ctx = this.ctx;
    const record = await ctx.service.category.findByTree();
    ctx.body = record;
  }
  async findByPage() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.category.findByPage(body);
    record.code = '10000'
    ctx.body = record;
  }
  }
  
  module.exports = CategoryController;