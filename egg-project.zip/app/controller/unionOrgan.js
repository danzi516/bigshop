'use strict';
const Controller = require('egg').Controller;

class UnionOrganController extends Controller {
  async add() {
    const ctx = this.ctx;
    //const body = ctx.request.body;
	const body = ctx.query;
    const record = await ctx.service.unionOrgan.add(body);
    ctx.body = record; 
  }
  async delete() {
    const ctx = this.ctx;
    const id = ctx.request.body.id;
    const record = await ctx.service.unionOrgan.delete(id);
    ctx.body = record;
  }
  async update() {
    const ctx = this.ctx;
    //const body = ctx.request.body;
	const body = ctx.query;
    const record = await ctx.service.unionOrgan.update(body);
    ctx.body = record;
  }
  async info() {
    const ctx = this.ctx;
    //const body = ctx.request.body;
	const body = ctx.query;
    const record = await ctx.service.unionOrgan.info(body);
    ctx.body = record;
  }
  async infoByPage() {
    const ctx = this.ctx;
    //const body = ctx.request.body;
	const body = ctx.query;
    const record = await ctx.service.unionOrgan.infoByPage(body);
    ctx.body = record;  
  }

  }
  
  module.exports = UnionOrganController;