'use strict';
const Controller = require('egg').Controller;

class ProductSpuController extends Controller {
  async add() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productSpu.add(body);
    ctx.body = record;
  }
  async delete() {
    const ctx = this.ctx;
    const id = ctx.request.body.id;
    const record = await ctx.service.productSpu.delete(id);
    ctx.body = record;
  }
  async update() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productSpu.update(body);
    ctx.body = record;
  }
  async info() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productSpu.info(body);
    ctx.body = record;
  }
  async findByPage() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productSpu.findByPage(body);
    record.code = '10000'
    ctx.body = record;
  }
  }
  
  module.exports = ProductSpuController;