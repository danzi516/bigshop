// const Controller = require('egg').Controller;
// const fs = require('mz/fs');
// const path = require('path')
// module.exports = class extends Controller {
//   async upload() {
//     const { ctx } = this;
//     const file = ctx.request.files[0];
//     console.log(file)
//     const name = 'egg-multipart-test/' + path.basename(file.filename);
//     console.log(name)
//     let result;
//     try {
//       // 处理文件，比如上传到云端
//     //   result = await ctx.oss.put(name, file.filepath);
//     // 读取文件
//     let file2 = fs.readFileSync(file.filepath) //files[0]表示获取第一个文件，若前端上传多个文件则可以遍历这个数组对象
//     // 将文件存到指定位置
//     fs.writeFileSync(path.join('./', `uploadfile/test.png`), file2)
//    // ctx.cleanupRequestFiles()

  
//    ctx.body = { code: 200, message: '', data: file.filename}
//     } finally {
//       // 需要删除临时文件
//       await fs.unlink(file.filepath);
//     }


//   }
// };

const  fs = require('fs')
const path = require('path')
const querystring =require('querystring');
const sendToWormhole = require('stream-wormhole');
const Controller = require('egg').Controller;

class upload extends Controller {
  async upload() {
    const { ctx } = this;

    let stream = await ctx.getFileStream()
    let filename = new Date().getTime() + stream.filename  // stream对象也包含了文件名，大小等基本信息
 
    // 创建文件写入路径
    let target = path.join('./', `app/public/uploadfile/${filename}`)

    const result = await new Promise((resolve, reject) => {
      // 创建文件写入流
      const remoteFileStrem = fs.createWriteStream(target)
      // 以管道方式写入流
      stream.pipe(remoteFileStrem)

      let errFlag 
      // 监听error事件
      remoteFileStrem.on('error', err => {
        errFlag = true
        // 停止写入
        sendToWormhole(stream)
        remoteFileStrem.destroy()
        console.log(err)
        reject(err)
      })
      
      // 监听写入完成事件
      remoteFileStrem.on('finish', () => {
        if (errFlag) return
        resolve({ filename, name: stream.fields.name })
      })
    })

    ctx.body = { code: 200, message: '', data: result }
  }
}
module.exports = upload;
