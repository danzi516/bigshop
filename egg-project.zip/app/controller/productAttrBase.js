'use strict';
const Controller = require('egg').Controller;

class ProductAttrBaseController extends Controller {
  async add() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productAttrBase.add(ctx.query);
    ctx.body = record;
  }
  async delete() {
    const ctx = this.ctx;
    const id = ctx.query.id;
    const record = await ctx.service.productAttrBase.delete(id);
    ctx.body = record;
  }
  async update() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productAttrBase.update(ctx.query);
    ctx.body = record;
  }
  async info() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productAttrBase.info(ctx.query);
    ctx.body = record;
  }

  }
  
  module.exports = ProductAttrBaseController;