'use strict';
const Controller = require('egg').Controller;

class AreaController extends Controller {
  async getProviceList() {
    const ctx = this.ctx;
    const record = await ctx.service.area.getProviceList();
    ctx.body = record;
  }
    async getCityList() {
		    const ctx = this.ctx;
    const id = ctx.query.id;
    const record = await ctx.service.area.getCityList(id);
    ctx.body = record;
  }
    async getAreaList() {
		    const ctx = this.ctx;
    const id = ctx.query.id;
    const record = await ctx.service.area.getAreaList(id);
    ctx.body = record;
  }

  }
  
  module.exports = AreaController;