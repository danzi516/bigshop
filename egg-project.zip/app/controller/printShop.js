'use strict';
const Controller = require('egg').Controller;

class PrintShopController extends Controller {
  async getInit() {
    const ctx = this.ctx;
    const orgId = ctx.query.orgId;
    const record = await ctx.service.printShop.getInit(orgId);
    ctx.body = record;
  }
  async getCustomer() {
    const ctx = this.ctx;
    const orgId = ctx.query.orgId;
    const record = await ctx.service.printShop.getCustomer(orgId);
    ctx.body = record;
  }
  async login() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.printShop.login(body);
    ctx.body = record;
  }
  async getSku() {
    const ctx = this.ctx;
    const orgId = ctx.query.orgId;
    const record = await ctx.service.printShop.getSku(orgId);
    ctx.body = record;
  }
  async getPrintCategory() {
    const ctx = this.ctx;
    const orgId = ctx.query.orgId;
    const record = await ctx.service.printShop.getCategory(orgId);
    ctx.body = record;
  }
  }
  module.exports = PrintShopController;