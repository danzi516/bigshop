'use strict';
const Controller = require('egg').Controller;

class ProductAttrSaleController extends Controller {
  async add() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productAttrSale.add(body);
    ctx.body = record;
  }
  async delete() {
    const ctx = this.ctx;
    const id = ctx.request.body.id;
    const record = await ctx.service.productAttrSale.delete(id);
    ctx.body = record;
  }
  async update() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productAttrSale.update(body);
    ctx.body = record;
  }
  async info() {
    const ctx = this.ctx;
    const body = ctx.request.query;
	  console.log(ctx.request.query); 
    const record = await ctx.service.productAttrSale.info(ctx.query);
    ctx.body = record;
  }

  }
  
  module.exports = ProductAttrSaleController;