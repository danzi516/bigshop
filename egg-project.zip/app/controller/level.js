'use strict';
const Controller = require('egg').Controller;

class LevelController extends Controller {
  async add() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.Level.add(body);
    ctx.body = record;
  }
  async delete() {
    const ctx = this.ctx;
    const id = ctx.request.body.id;
    const record = await ctx.service.Level.delete(id);
    ctx.body = record;
  }
  async update() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.Level.update(body);
    ctx.body = record;
  }
  async info() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.Level.info(body);
    ctx.body = record;
  }
  async infoByPage() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    console.log(body);
    const record = await ctx.service.Level.infoByPage(body);
    ctx.body = record;
  }
  }
  
  module.exports = LevelController;