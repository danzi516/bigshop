'use strict';
const Controller = require('egg').Controller;

class OrganCustomerController extends Controller {
  async add() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.organCustomer.add(body);
    ctx.body = record;
  }
  async delete() {
    const ctx = this.ctx;
    const id = ctx.request.body.id;
    const record = await ctx.service.organCustomer.delete(id);
    ctx.body = record;
  }
  async update() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.organCustomer.update(body);
    ctx.body = record;
  }
  async info() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.organCustomer.info(body);
    ctx.body = record;
  }
  async infoByPage() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    console.log(body);
    const record = await ctx.service.organCustomer.infoByPage(body);
    ctx.body = record;
  }
  }
  
  module.exports = OrganCustomerController;