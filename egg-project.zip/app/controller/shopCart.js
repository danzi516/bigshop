'use strict';
const Controller = require('egg').Controller;

class ShopCartController extends Controller {
  async add() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.shopCart.add(body);
    ctx.body = record;
  }
  async delete() {
    const ctx = this.ctx;
    const id = ctx.request.body.id;
    const record = await ctx.service.shopCart.delete(id);
    ctx.body = record;
  }
  async update() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.shopCart.update(body);
    ctx.body = record;
  }
  async info() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.shopCart.info(body);
    ctx.body = record;
  }
  async findByPage() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.shopCart.findByPage(body);
    record.code = '10000'
    ctx.body = record;
  }
  }
  
  module.exports = ShopCartController;