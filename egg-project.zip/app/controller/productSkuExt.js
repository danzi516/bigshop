'use strict';
const Controller = require('egg').Controller;

class ProductSkuExtController extends Controller {
  async add() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productSkuExt.add(body);
    ctx.body = record;
  }
  async delete() {
    const ctx = this.ctx;
    const id = ctx.request.body.id;
    const record = await ctx.service.productSkuExt.delete(id);
    ctx.body = record;
  }
  async update() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productSkuExt.update(body);
    ctx.body = record;
  }
  async info() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productSkuExt.info(body);
    ctx.body = record;
  }
  }
  
  module.exports = ProductSkuExtController;