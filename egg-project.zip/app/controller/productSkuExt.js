'use strict';
const Controller = require('egg').Controller;

class ProductSkuExtController extends Controller {
  async add() {
    const ctx = this.ctx;
    //const body = ctx.request.body;
	const body = ctx.query;
    const record = await ctx.service.productSkuExt.add(body);
    ctx.body = record;
  }
  
    async bulkCreate() {
    const ctx = this.ctx;
    const body = ctx.request.body.skuAttrList;
  // const body = ctx.query.skuAttrList;
    const record = await ctx.service.productSkuExt.bulkCreate(body);
    ctx.body = record;
  }
  
  async delete() {
    const ctx = this.ctx;
    const id = ctx.request.body.id;
    const record = await ctx.service.productSkuExt.delete(id);
    ctx.body = record;
  }

  async deleteBySkuId() {
    const ctx = this.ctx;
    // const id = ctx.request.body.skuId;
    const id = ctx.query.skuId;
    const record = await ctx.service.productSkuExt.deleteBySkuId(id);
    ctx.body = record;
  }

  async update() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productSkuExt.update(body);
    ctx.body = record;
  }
  async info() {
    const ctx = this.ctx;
    //const body = ctx.request.body;
	const body = ctx.query;
    const record = await ctx.service.productSkuExt.info(body);
    ctx.body = record;
  }
  }
  
  module.exports = ProductSkuExtController;