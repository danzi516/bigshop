'use strict';
const Controller = require('egg').Controller;

class ProductAttrValueController extends Controller {
  async add() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productAttrValue.add(body);
    ctx.body = record;
  }
  async delete() {
    const ctx = this.ctx;
    const id = ctx.request.body.id;
    const record = await ctx.service.productAttrValue.delete(id);
    ctx.body = record;
  }
  async update() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productAttrValue.update(body);
    ctx.body = record;
  }
  async info() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.productAttrValue.info(body);
    ctx.body = record;
  }

  }
  
  module.exports = ProductAttrValueController;