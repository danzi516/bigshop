'use strict';
const Controller = require('egg').Controller;

class OrganMemberController extends Controller {
  async add() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.organMember.add(body);
    ctx.body = record;
  }
  async delete() {
    const ctx = this.ctx;
    const id = ctx.request.body.id;
    const record = await ctx.service.organMember.delete(id);
    ctx.body = record;
  }
  async update() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.organMember.update(body);
    ctx.body = record;
  }
  async info() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    const record = await ctx.service.organMember.info(body);
    ctx.body = record;
  }
  async infoByPage() {
    const ctx = this.ctx;
    const body = ctx.request.body;
    console.log(body);
    const record = await ctx.service.organMember.infoByPage(body);
    ctx.body = record;
  }
  }
  
  module.exports = OrganMemberController;