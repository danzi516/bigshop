const Service = require('egg').Service;
const Sequelize = require('sequelize');
class CategoryService extends Service {
    //获取树
    async findByTree() {
      const category = await this.app.model.query("SELECT a.*,b.name as pname from (SELECT * FROM	product_category a WHERE	a.pid IN (SELECT c.id FROM product_category c WHERE c.pid = 115)) as a , product_category b where a.pid = b.id",{type:'SELECT'});
      var nodes = []
      var pNodes = {}
      var cNodes = []
      
      for(let v in category){
        var cNode = {}
        if(v == 0){
            pNodes.text = category[v].pname
            pNodes.id = category[v].pid
        }
        if(pNodes.id != category[v].pid){
            pNodes.nodes = cNodes
            nodes.push(pNodes)
            pNodes = {}
            cNodes = []
            pNodes.text = category[v].pname
            pNodes.id = category[v].pid
        }
        cNode.text = category[v].name
        cNode.id = category[v].id
        cNodes.push(cNode)
        if(v == category.length-1){
            pNodes.nodes = cNodes
            nodes.push(pNodes)
        }
      }
      return { nodes };
    }
  async add(body) {
    console.log(body)
    const category = await this.app.model.Category.create(body)
    return { category };
  }
  async delete(id) {
    console.log(id)
    const category = await this.app.model.Category.destroy({where:{id:id}})
  return { category };
}
  async update(body) {
    console.log(body)
    const id = body.id
    const category = await this.app.model.Category.update(body,{where:{id:id}})
  return { category };
  }
  async info(query) {
    console.log(query)
    const category = await this.app.model.Category.findAll({where:query})
  return { category };
  }
  async findByPage(query) {
    console.log(query)
    const size = query.size
    const page = query.page
    const name = query.name
    const pidList = query.pidList
    const Op = Sequelize.Op
    let Filter = {name,pid}
    name = name ? { name: { [Op.like]: '%'+name+'%'}} : {}
    pid = pidList ? { pid:{[Op.in]:pidList}} : {}
    console.log(nameFilter)
    const category = await this.app.model.Category.findAndCountAll({include:[{model:this.app.model.CategoryP}],where:Filter,limit:parseInt(size),offset:size * (page - 1)})
  return { category };
  }
  }
module.exports = CategoryService;