const Service = require('egg').Service;
const Sequelize = require('sequelize');
class CategoryService extends Service {
    //获取树
    async findByTree(query) {
      const category = await this.app.model.query("SELECT a.*,b.name as pname from (SELECT * FROM	product_category a WHERE	a.pid IN (SELECT c.id FROM product_category c WHERE c.orgId = "+query.orgId+")) as a , product_category b where a.pid = b.id",{type:'SELECT'});
      var categoryNodes = []
      var pNodes = {}
      var cNodes = []
      
      for(let v in category){
        var cNode = {}
        if(v == 0){
            pNodes.label = category[v].pname
            pNodes.id = category[v].pid
        }
        if(pNodes.id != category[v].pid){
            pNodes.children = cNodes
            nodes.push(pNodes)
            pNodes = {}
            cNodes = []
            pNodes.label = category[v].pname
            pNodes.id = category[v].pid
        }
        cNode.label = category[v].name
        cNode.id = category[v].id
        cNodes.push(cNode)
        if(v == category.length-1){
            pNodes.children = cNodes
            categoryNodes.push(pNodes)
        }
      }
      return { categoryNodes };
    }
  async add(body) {
    console.log(body)
    const category = await this.app.model.Category.create(body)
    return { category };
  }
  async delete(id) {
    console.log(id)
    const category = await this.app.model.Category.destroy({where:{id:id}})
  return { category };
}
  async update(body) {
    console.log(body)
    const id = body.id
    const category = await this.app.model.Category.update(body,{where:{id:id}})
  return { category };
  }
  async info(query) {
    console.log(query)
	var name = query.name
	var orgId = query.orgId
	var level = query.level
	let Filter = {}
	if(name){Filter['name'] = {[Op.like]: '%'+name+'%'}}
	if(orgId){Filter['orgId'] = orgId}
	if(level){Filter['level'] = level}
    return await this.app.model.Category.findAll({where:Filter})
  //return { category };
  }
  async findByPage(query) {
    console.log(query)
    const size = query.pageSize
    const page = query.pageIndex
    var name = query.name
	var orgId = query.orgId
    const pidList = query.pidList
    const Op = Sequelize.Op
    //let Filter = {name,orgId}
	let Filter = {}
	if(name){Filter['name'] = {[Op.like]: '%'+name+'%'}}
	if(orgId){Filter['orgId'] = orgId}
    //let Filter = name ? { name: { [Op.like]: '%'+name+'%'},orgId:orgId} : {orgId:orgId}
    //pid = pidList ? { pid:{[Op.in]:pidList}} : {}
    console.log(Filter)
    return await this.app.model.Category.findAndCountAll({include:[{model:this.app.model.CategoryP}],where:Filter,limit:parseInt(size),offset:size * (page - 1)})
  //return { category };
  }
  }
module.exports = CategoryService;