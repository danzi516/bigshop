const Service = require('egg').Service;
class AttrBaseService extends Service {
  async add(body) {
    console.log(body)
    const skuId = body.skuId;
    const name = body.name;
    const value = body.value;  
    const ProductAttrBase = await this.app.model.ProductAttrBase.create(body)
    return { ProductAttrBase };
  }
  async delete(id) {
    console.log(id)
    const ProductAttrBase = await this.app.model.ProductAttrBase.destroy({where:{id:id}})
  return { ProductAttrBase };
}
async update(body) {
  console.log(body)
  const id = body.id
  const ProductAttrBase = await this.app.model.ProductAttrBase.update(body,{where:{id:id}})
return { ProductAttrBase };
}
async info(query) {
  console.log(query)
  const skuId = query.skuId;
  let Filter = skuId ? { skuId: skuId } : {}
  const ProductAttrBase = await this.app.model.ProductAttrBase.findAll({include:[{model:this.app.model.ProductSku}],where:Filter})
return { ProductAttrBase };
}

}
module.exports = AttrBaseService;