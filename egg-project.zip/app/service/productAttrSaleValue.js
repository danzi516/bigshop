const Service = require('egg').Service;
class AttrSaleValueService extends Service {
  async add(body) {
    console.log(body)
    const ProductAttrSaleValue = await this.app.model.ProductAttrSaleValue.create(body)
    return { ProductAttrSaleValue };
  }
  async delete(id) {
    console.log(id)
    const ProductAttrSaleValue = await this.app.model.ProductAttrSaleValue.destroy({where:{id:id}})
  return { ProductAttrSaleValue };
}
async update(body) {
  console.log(body)
  const id = body.id
  const ProductAttrSaleValue = await this.app.model.ProductAttrSaleValue.update(body,{where:{id:id}})
return { ProductAttrSaleValue };
}
async info(query) {
  console.log(query)
  const attrId = query.attrId;
  let Filter = attrId ? { attrId: attrId } : {}
  const ProductAttrSaleValue = await this.app.model.ProductAttrSaleValue.findAll({include:[{model:this.app.model.ProductAttrSale}],where:Filter})
return { ProductAttrSaleValue };
}

}
module.exports = AttrSaleValueService;