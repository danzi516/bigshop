const Service = require('egg').Service;
const Sequelize = require('sequelize');
class LevelService extends Service {
  async add(body) {
    console.log(body)
    const Level = await this.app.model.Level.create(body)
    return { Level };
  }
  async delete(id) {
    console.log(id)
    const Level = await this.app.model.Level.destroy({where:{id:id}})
  return { Level };
}
async update(body) {
  console.log(body)
  const id = body.id
  const Level = await this.app.model.Level.update(body,{where:{id:id}})
return { Level };
}
async info(query) {
  console.log(query)
  const Level = await this.app.model.Level.findAll({include:[{model:this.app.model.Category},{model:this.app.model.Brand}],where:query})
return { Level };
}
async infoByPage(query) {
  var offset=query.offset*1;
  var limit=query.limit*1;
  var key = query.search;
  const Op = Sequelize.Op;
  let Filter = key ? {[Op.or]: [{name: { [Op.like]: '%'+key+'%'}}, {desc: { [Op.like]: '%'+key+'%'}}] } : {}
  // var total=await this.ctx.model.OrganCustomer.findAll({}).count();
  // var result=await this.ctx.model.OrganCustomer.findAndCountAll({limit: limit,offset: offset});
  // var rows=await this.ctx.model.OrganCustomer.findAll({}).skip((page-1)*pageSize).limit(pageSize);
return await this.ctx.model.Level.findAndCountAll({where: Filter,limit: limit,offset: offset});;
}
}
module.exports = LevelService;