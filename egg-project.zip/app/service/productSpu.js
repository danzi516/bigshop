const Service = require('egg').Service;
const Sequelize = require('sequelize');
class SpuService extends Service {
  async add(body) {
    console.log(body)
    const ProductSpu = await this.app.model.ProductSpu.create(body)
    return { ProductSpu };
  }
  async delete(id) {
    console.log(id)
    const ProductSpu = await this.app.model.ProductSpu.destroy({where:{id:id}})
  return { ProductSpu };
}
async update(body) {
  console.log(body)
  const id = body.id
  const ProductSpu = await this.app.model.ProductSpu.update(body,{where:{id:id}})
return { ProductSpu };
}
async info(query) {
  console.log(query)
  const ProductSpu = await this.app.model.ProductSpu.findAll({include:[{model:this.app.model.Category},{model:this.app.model.Brand}],where:query})
return { ProductSpu };
}
async findByPage(query) {
  console.log(query)
  const size = query.size
  const page = query.page
  const name = query.name
  const Op = Sequelize.Op
  let nameFilter = name ? { name: { [Op.like]: '%'+name+'%'}} : {}
  console.log(nameFilter)
  const ProductSpu = await this.app.model.ProductSpu.findAll({include:[{model:this.app.model.Category},{model:this.app.model.Brand}],where:nameFilter,limit:parseInt(size),offset:size * (page - 1),})
return { ProductSpu };
}
}
module.exports = SpuService;