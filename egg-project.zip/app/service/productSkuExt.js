const Service = require('egg').Service;
const Sequelize = require('sequelize');
class SkuExtService extends Service {
  async add(body) {
    console.log(body)
    const ProductSkuExt = await this.app.model.ProductSkuExt.create(body)
    return {
      ProductSkuExt
    };
  }
  
    async bulkCreate(body) {
      console.log(typeof(body))
      console.log(body)
    const ProductSkuExt = await this.app.model.ProductSkuExt.bulkCreate(body,{ fields: ['attrIndex','priceFee','state','childProductNo','skuId'] })
    return {
      ProductSkuExt
    };
  }
  
  async delete(id) {
    console.log(id)
    const ProductSkuExt = await this.app.model.ProductSkuExt.destroy({
      where: {
        id: id
      }
    })
    return {
      ProductSkuExt
    };
  }

  async deleteBySkuId(id) {
    console.log(id)
    const ProductSkuExt = await this.app.model.ProductSkuExt.destroy({
      where: {
        skuId: id
      }
    })
    return {
      ProductSkuExt
    };
  }

  async update(body) {
    console.log(body)
    const id = body.id
    const ProductSkuExt = await this.app.model.ProductSkuExt.update(body, {
      where: {
        id: id
      }
    })
    return {
      ProductSkuExt
    };
  }
  async info(query) {
    console.log(query)
    const Op = Sequelize.Op
    let ids = {
      id: {
        [Op.in]: Sequelize.col('sku.attrs')
      }
    }
    const ProductSkuExt = await this.app.model.ProductSku.findAll({
      include: [{
        model: this.app.model.Category
      }, {
        model: this.app.model.Brand
      }, {
        model: this.app.model.ProductSpu
      }],
      where: query
    })
    return {
      ProductSkuExt
    };
  }
}
module.exports = SkuExtService;