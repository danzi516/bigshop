const Service = require('egg').Service;
class BrandCategoryService extends Service {
  async add(body) {
    console.log(body)
    const brandCategory = await this.app.model.BrandCategory.create(body)
    return { brandCategory };
  }
  async delete(id) {
    console.log(id)
    const brandCategory = await this.app.model.BrandCategory.destroy({where:{id:id}})
  return { brandCategory };
}
async update(body) {
  console.log(body)
  const id = body.id
  const brandCategory = await this.app.model.BrandCategory.update(body,{where:{id:id}})
return { brandCategory };
}
async info(query) {
  console.log(query)
  const brandCategory = await this.app.model.BrandCategory.findAll({include:[{model:this.app.model.Category},{model:this.app.model.Brand}],where:query})
return { brandCategory };
}
async findByPage(query) {
  console.log(query)
  const size = query.size
  const page = query.page
  const brandCategory = await this.app.model.Category.findAndCountAll({include:[{model:this.app.model.Category},{model:this.app.model.Brand}],limit:parseInt(size),offset:size * (page - 1)})
return { brandCategory };
}
}
module.exports = BrandCategoryService;