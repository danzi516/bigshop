const Service = require('egg').Service;
const Sequelize = require('sequelize');
class UnionOrganService extends Service {
  async add(body) {
    console.log(body)
    const record = await this.app.model.UnionOrgan.create(body)
    return { record };
  }
  async delete(id) {
    console.log(id)
    const record = await this.app.model.UnionOrgan.destroy({where:{id:id}})
  return { record };
}
async update(body) {
  console.log(body)
  const id = body.id
  const record = await this.app.model.UnionOrgan.update(body,{where:{id:id}})
return { record };
}
async info(query) {
  console.log(query)
  const record = await this.app.model.UnionOrgan.findAll({include:[{model:this.app.model.Union},{model:this.app.model.Organ}],where:query})
return { record };
}
async infoByPage(query) {
console.log(query)
    const size = query.pageSize
    const page = query.pageIndex
    var name = query.name
	var orgId = query.orgId
	var unionId = query.unionId
    const pidList = query.pidList
    const Op = Sequelize.Op
    //let Filter = {name,orgId}
	let Filter = {}
	if(name){Filter['name'] = {[Op.like]: '%'+name+'%'}}
	if(orgId){Filter['orgId'] = orgId} 
	if(unionId){Filter['unionId'] = unionId}
	console.log(Filter)
  const record = await this.app.model.UnionOrgan.findAndCountAll({include:[{model:this.app.model.Union},{model:this.app.model.Organ}],limit:parseInt(size),offset:size * (page - 1),where:Filter})
return { record };
}
}
module.exports = UnionOrganService;