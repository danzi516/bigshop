const Service = require('egg').Service;
const Sequelize = require('sequelize');
class SkuService extends Service {
  async add(body) {
    console.log(body)
    const ProductSku = await this.app.model.ProductSku.create(body)
    return { ProductSku };
  }
  async delete(id) {
    console.log(id)
    const ProductSku = await this.app.model.ProductSku.destroy({where:{id:id}})
  return { ProductSku };
}
async update(body) {
  console.log(body)
  const id = body.id
  const ProductSku = await this.app.model.ProductSku.update(body,{where:{id:id}})
return { ProductSku };
}
async info(query) {
  console.log(query)
  const ProductSku = await this.app.model.ProductSku.findAll({include:[{model:this.app.model.Category},{model:this.app.model.Brand},{model:this.app.model.ProductSpu},{model:this.app.model.ProductSkuExt},{model:this.app.model.ProductAttrBase}],where:query})
return { ProductSku };
}
async findByPage(query) {
  console.log(query)
  const size = query.pageSize
  const page = query.pageIndex
  var name = query.name
  var orgId = query.orgId
  var categoryId = query.cid
  var brandId = query.bid
  const Op = Sequelize.Op  
  let Filter = {}
  if(name){Filter['name'] = {[Op.like]: '%'+name+'%'}}
  if(orgId){Filter['sellOID'] = orgId}
  if(categoryId){Filter['categoryId'] = categoryId}
  if(brandId){Filter['brandId'] = brandId}
  //let Filter = name ? { name: { [Op.like]: '%'+name+'%'},sellOID:orgId} : {sellOID:orgId}
  console.log(Filter)
  return await this.app.model.ProductSku.findAndCountAll({include:[{model:this.app.model.Category},{model:this.app.model.Brand},{model:this.app.model.ProductSpu}],where:Filter,limit:parseInt(size),offset:size * (page - 1),})
//return { ProductSku };
}
}
module.exports = SkuService;