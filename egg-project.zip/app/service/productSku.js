const Service = require('egg').Service;
const Sequelize = require('sequelize');
class SkuService extends Service {
  async add(body) {
    console.log(body)
    const ProductSku = await this.app.model.ProductSku.create(body)
    return { ProductSku };
  }
  async delete(id) {
    console.log(id)
    const ProductSku = await this.app.model.ProductSku.destroy({where:{id:id}})
  return { ProductSku };
}
async update(body) {
  console.log(body)
  const id = body.id
  const ProductSku = await this.app.model.ProductSku.update(body,{where:{id:id}})
return { ProductSku };
}
async info(query) {
  console.log(query)
  const ProductSku = await this.app.model.ProductSku.findAll({include:[{model:this.app.model.Category},{model:this.app.model.Brand},{model:this.app.model.ProductSpu},{model:this.app.model.ProductSkuExt},{model:this.app.model.ProductAttrBase}],where:query})
return { ProductSku };
}
async findByPage(query) {
  console.log(query)
  const size = query.size
  const page = query.page
  const name = query.name
  const Op = Sequelize.Op
  let nameFilter = name ? { name: { [Op.like]: '%'+name+'%'}} : {}
  console.log(nameFilter)
  const ProductSku = await this.app.model.ProductSku.findAll({include:[{model:this.app.model.Category},{model:this.app.model.Brand},{model:this.app.model.ProductSpu}],where:nameFilter,limit:parseInt(size),offset:size * (page - 1),})
return { ProductSku };
}
}
module.exports = SkuService;