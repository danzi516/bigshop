const Service = require('egg').Service;
const Sequelize = require('sequelize');
class OrganMemberService extends Service {
  async add(body) {
    console.log(body)
    const OrganMember = await this.app.model.OrganMember.create(body)
    return { OrganMember };
  }
  async delete(id) {
    console.log(id)
    const OrganMember = await this.app.model.OrganMember.destroy({where:{id:id}})
  return { OrganMember };
}
async update(body) {
  console.log(body)
  const id = body.id
  const OrganMember = await this.app.model.OrganMember.update(body,{where:{id:id}})
return { OrganMember };
}
async info(query) {
  console.log(query)
  const OrganMember = await this.app.model.OrganMember.findAll({include:[{model:this.app.model.Organ},{model:this.app.model.User},{model:this.app.model.MemberLevel}],where:query})
return { OrganMember };
}
async infoByPage(query) {
  var offset=query.offset*1;
  var limit=query.limit*1;
  var key = query.search;
  const Op = Sequelize.Op;
  let Filter = key ? {[Op.or]: [{linkName: { [Op.like]: '%'+key+'%'}}, {linkPhone: { [Op.like]: '%'+key+'%'}}] } : {}
  // var total=await this.ctx.model.OrganMember.findAll({}).count();
  // var result=await this.ctx.model.OrganMember.findAndCountAll({limit: limit,offset: offset});
  // var rows=await this.ctx.model.OrganMember.findAll({}).skip((page-1)*pageSize).limit(pageSize);
return await this.ctx.model.OrganMember.findAndCountAll({where: Filter,limit: limit,offset: offset});;
}
}
module.exports = OrganMemberService;