const Service = require('egg').Service;
const Sequelize = require('sequelize');
class SpuSkuAttrService extends Service {
  async add(body) {
    console.log(body)
    const productSpuSkuAttrMap = await this.app.model.ProductSpuSkuAttrMap.create(body)
    return { productSpuSkuAttrMap };
  }
  async delete(id) {
    console.log(id)
    const productSpuSkuAttrMap = await this.app.model.ProductSpuSkuAttrMap.destroy({where:{id:id}})
  return { productSpuSkuAttrMap };
}
async update(body) {
  console.log(body)
  const id = body.id
  const productSpuSkuAttrMap = await this.app.model.ProductSpuSkuAttrMap.update(body,{where:{id:id}})
return { productSpuSkuAttrMap };
}
async info(query) {
  console.log(query)
  const Op = Sequelize.Op
  let ids = { id: { [Op.in]: Sequelize.col('sku.attrs')}} 
  const productSpuSkuAttrMap = await this.app.model.ProductSpuSkuAttrMap.findAll({include:[{model:this.app.model.ProductSaleAttr},{model:this.app.model.ProductAttrSaleValue},{model:this.app.model.ProductSpu},{model:this.app.model.ProductSku}],where:query})
return { productSpuSkuAttrMap };
}
async findByPage(query) {
  console.log(query)
  const size = query.size
  const page = query.page
  const name = query.name
  const Op = Sequelize.Op
  let nameFilter = name ? { name: { [Op.like]: '%'+name+'%'}} : {}
  console.log(nameFilter)
  const productSpuSkuAttrMap = await this.app.model.ProductSpuSkuAttrMap.findAll({include:[{model:this.app.model.ProductSaleAttr},{model:this.app.model.ProductAttrSaleValue},{model:this.app.model.ProductSpu},{model:this.app.model.ProductSku}],where:nameFilter,limit:parseInt(size),offset:size * (page - 1),})
return { productSpuSkuAttrMap };
}
}
module.exports = SpuSkuAttrService;