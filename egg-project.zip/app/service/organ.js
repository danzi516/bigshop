const Service = require('egg').Service;
const Sequelize = require('sequelize');
class OrganService extends Service {
  async add(body) {
    console.log(body)
    const Organ = await this.app.model.Organ.create(body)
    return { Organ };
  }
  async delete(id) {
    console.log(id)
    const Organ = await this.app.model.Organ.destroy({where:{id:id}})
  return { Organ };
}
async update(body) {
  console.log(body)
  const id = body.id
  const Organ = await this.app.model.Organ.update(body,{where:{id:id}})
return { Organ };
}
async info(query) {
  console.log(query)
    const Op = Sequelize.Op;
  var bossPhone = query.bossPhone
  let Filter = {}
  if(bossPhone){Filter['bossPhone'] = {[Op.like]: '%'+bossPhone+'%'}}
  const Organ = await this.app.model.Organ.findAll({where:Filter})
return { Organ };
}
async infoByPage(query) {
  var offset=query.offset*1;
  var limit=query.limit*1;
  var key = query.search;
  const Op = Sequelize.Op;
  let Filter = key ? {[Op.or]: [{name: { [Op.like]: '%'+key+'%'}}, {boosName: { [Op.like]: '%'+key+'%'}}] } : {}
  // var total=await this.ctx.model.Organ.findAll({}).count();
  // var result=await this.ctx.model.Organ.findAndCountAll({limit: limit,offset: offset});
  // var rows=await this.ctx.model.Organ.findAll({}).skip((page-1)*pageSize).limit(pageSize);
return await this.ctx.model.Organ.findAndCountAll({where: Filter,limit: limit,offset: offset});;
}
}
module.exports = OrganService;