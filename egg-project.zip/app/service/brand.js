const Service = require('egg').Service;
const Sequelize = require('sequelize');
class BrandService extends Service {
  async groupByPyf(query) {
    console.log(query)
    const brand = await this.app.model.Brand.findAll({ attributes: ['pyf'], group: 'pyf' })
    return { brand };
  }
  async add(body) {
    console.log(body)
    const brand = await this.app.model.Brand.create(body)
    return { brand };
  }
  async delete(id) {
    console.log(id)
    const brand = await this.app.model.Brand.destroy({ where: { id: id } })
    return { brand };
  }
  async update(body) {
    console.log(body)
    const id = body.id
    const brand = await this.app.model.Brand.update(body, { where: { id: id } })
    return { brand };
  }
  async info(query) {
    console.log(query)
    const orgId = query.orgId;
    let Filter = orgId ? { orgId: orgId } : {}
    const brand = await this.app.model.Brand.findAll({ where: Filter })
    return { brand };
  }
  async findByPage(query) {
    console.log(query);
    const size = query.pageSize
    const page = query.pageIndex
    const name = query.name
    const Op = Sequelize.Op
	var orgId = query.orgId
    let nameFilter = name ? { name: { [Op.like]: '%' + name + '%' },orgId:orgId } : {orgId:orgId}
    console.log(nameFilter)
    return await this.app.model.Brand.findAndCountAll({ where: nameFilter, limit: parseInt(size), offset: size * (page - 1)});
  }
}
module.exports = BrandService;