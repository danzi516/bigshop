const Service = require('egg').Service;
class PrintShopService extends Service {
  async getInit(orgId) {
    const category = await this.app.model.query("SELECT ca.`name`,ca.id as categoryId FROM product_sku sku LEFT JOIN product_category ca on sku.categoryId = ca.id where sellOID = "+orgId+" GROUP BY sku.categoryId;",{type:'SELECT'})
    let categorySku = []
    for(let i=0;i<category.length;i++){
      let categoryId = category[i].categoryId
      let categoryName = category[i].name
      console.log(categoryId)
      var ProductSku = await this.app.model.ProductSku.findAll({include:[{model:this.app.model.Category},{model:this.app.model.Brand},{model:this.app.model.ProductSpu},{model:this.app.model.ProductSkuExt}],where:{'sellOID':orgId,'categoryId':category[i].categoryId}})  
      categorySku = categorySku.concat({'categoryId':categoryId,'ProductSku':ProductSku,'categoryName':categoryName})
    }
    //const ProductSku = await this.app.model.ProductSku.findAll({include:[{model:this.app.model.Category},{model:this.app.model.Brand},{model:this.app.model.ProductSpu},{model:this.app.model.ProductSkuExt}],where:{'sellOID':orgId}}) 
    let data = {'category':category,'categorySku':categorySku}
    return { data };
  }

  async getCustomer(orgId) {
    const customers = await this.app.model.OrganCustomer.findAll({where:{'orgId':orgId}})
    return { customers };
  }

  async login(body) {
    const user = await this.app.model.User.findAll({where:body})
    var state ='0'
    if(user.length>0){
      state ='1'
    }
    var data = {'user':user,'state':state}
    return { state };
  }

  async getSku(orgId) {
    const sku = await this.app.model.query("SELECT sku.*,skuExt.*,ca.`name` as 'categoryName' FROM product_sku_ext skuExt LEFT JOIN product_sku sku on sku.id = skuExt.skuId LEFT JOIN product_category ca on ca.id =sku.categoryId where sku.sellOID ="+orgId+";",{type:'SELECT'})
    return { sku };
  }
  async getCategory(orgId) {
    const category = await this.app.model.query("SELECT product_category.id,product_category.`name` FROM product_sku,product_category where product_sku.sellOID ="+orgId+" and product_sku.categoryId = product_category.id GROUP BY categoryId ;",{type:'SELECT'})
    return { category };
  }
}
module.exports = PrintShopService;