const Service = require('egg').Service;
class AttrValueService extends Service {
  async add(body) {
    console.log(body)
    const ProductAttrValue = await this.app.model.ProductAttrValue.create(body)
    return { ProductAttrValue };
  }
  async delete(id) {
    console.log(id)
    const ProductAttrValue = await this.app.model.ProductAttrValue.destroy({where:{id:id}})
  return { ProductAttrValue };
}
async update(body) {
  console.log(body)
  const id = body.id
  const ProductAttrValue = await this.app.model.ProductAttrValue.update(body,{where:{id:id}})
return { ProductAttrValue };
}
async info(query) {
  console.log(query)
  const ProductAttrValue = await this.app.model.ProductAttrValue.findAll({include:[{model:this.app.model.ProductAttrValue}],where:query})
return { ProductAttrValue };
}

}
module.exports = AttrValueService;