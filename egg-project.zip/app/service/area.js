const Service = require('egg').Service;
const Sequelize = require('sequelize');
class AreaService extends Service {

async getProviceList() {
  const area = await this.app.model.Area.findAll({where:{Grade:2}})
return { area };
}
async getCityList(body) {
  console.log(body)
  const id = body.id
  const area = await this.app.model.Area.findAll(body,{where:{pid:id}})
return { area };
}
async getAreaList(body) {
  console.log(body)
  const id = body.id
  const area = await this.app.model.Area.findAll(body,{where:{pid:id}})
return { area };
}

}

module.exports = AreaService;