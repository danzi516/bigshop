const Service = require('egg').Service;
const Sequelize = require('sequelize');
class AreaService extends Service {

async getProviceList() {
  const area = await this.app.model.Area.findAll({where:{Grade:2}})
return { area };
}
async getCityList(id) {
  console.log(id)
  const area = await this.app.model.Area.findAll({where:{ParentID:id}})
return { area };
}
async getAreaList(id) {
  console.log(id)

  const area = await this.app.model.Area.findAll({where:{ParentID:id}})
return { area };
}

}

module.exports = AreaService;