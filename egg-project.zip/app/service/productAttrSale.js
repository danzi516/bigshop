const Service = require('egg').Service;
class AttrSaleService extends Service {
  async add(body) {
    console.log(body)
    const ProductAttrSale = await this.app.model.ProductAttrSale.create(body)
    return { ProductAttrSale };
  }
  async delete(id) {
    console.log(id)
    const ProductAttrSale = await this.app.model.ProductAttrSale.destroy({where:{id:id}})
  return { ProductAttrSale };
}
async update(body) {
  console.log(body)
  const id = body.id
  const ProductAttrSale = await this.app.model.ProductAttrSale.update(body,{where:{id:id}})
return { ProductAttrSale };
}
async info(query) {
  console.log(query)
  const skuId = query.skuId
  let Filter = skuId ? { skuId: skuId } : {}
  const ProductAttrSale = await this.app.model.ProductAttrSale.findAll({include:[{model:this.app.model.ProductAttrSaleValue}],where:Filter})
return { ProductAttrSale };
}

}
module.exports = AttrSaleService;