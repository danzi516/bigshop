const Service = require('egg').Service;
const Sequelize = require('sequelize');
class UserService extends Service {
  async add(body) {
    console.log(body)
    const User = await this.app.model.User.create(body)
    return { User };
  }
  async delete(id) {
    console.log(id)
    const User = await this.app.model.User.destroy({where:{id:id}})
  return { User };
}
async update(body) {
  console.log(body)
  const id = body.id
  const User = await this.app.model.User.update(body,{where:{id:id}})
return { User };
}
async info(query) {
  console.log(query)
  const User = await this.app.model.User.findAll({where:query})
return { User };
}
async findByPage(query) {
  console.log(query)
  const size = query.size
  const page = query.page
  const name = query.name
  const Op = Sequelize.Op
  let nameFilter = name ? { name: { [Op.like]: '%'+name+'%'}} : {}
  console.log(nameFilter)
  const User = await this.app.model.User.findAll({where:nameFilter,limit:parseInt(size),offset:size * (page - 1),})
return { User };
}
}
module.exports = UserService;