const Service = require('egg').Service;
class AttrService extends Service {
  async add(body) {
    console.log(body)
    const ProductAttr = await this.app.model.ProductAttr.create(body)
    return { ProductAttr };
  }
  async delete(id) {
    console.log(id)
    const ProductAttr = await this.app.model.ProductAttr.destroy({where:{id:id}})
  return { ProductAttr };
}
async update(body) {
  console.log(body)
  const id = body.id
  const ProductAttr = await this.app.model.ProductAttr.update(body,{where:{id:id}})
return { ProductAttr };
}
async info(query) {
  console.log(query)
  const ProductAttr = await this.app.model.ProductAttr.findAll({include:[{model:this.app.model.ProductAttrValue}],where:query})
return { ProductAttr };
}

}
module.exports = AttrService;