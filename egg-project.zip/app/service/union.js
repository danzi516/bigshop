const Service = require('egg').Service;
class UnionService extends Service {
  async add(body) {
    console.log(body)
    const Union = await this.app.model.Union.create(body)
    return { Union };
  }
  async delete(id) {
    console.log(id)
    const Union = await this.app.model.Union.destroy({where:{id:id}})
  return { Union };
}
async update(body) {
  console.log(body)
  const id = body.id
  const Union = await this.app.model.Union.update(body,{where:{id:id}})
return { Union };
}
async info(query) {
  console.log(query)
  const Union = await this.app.model.Union.findAll({include:[{model:this.app.model.User},{model:this.app.model.Organ}],where:query})
return { Union };
}
async infoByPage(query) {
  console.log(query)
  const size = query.size
  const page = query.page
  const Union = await this.app.model.Category.findAndCountAll({include:[{model:this.app.model.User},{model:this.app.model.Organ}],limit:parseInt(size),offset:size * (page - 1)})
return { Union };
}
}
module.exports = UnionService;