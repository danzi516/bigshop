const Service = require('egg').Service;
const Sequelize = require('sequelize');
class ShopCartService extends Service {
  async add(body) {
    console.log(body)
    const ShopCart = await this.app.model.ShopCart.create(body)
    return { ShopCart };
  }
  async delete(id) {
    console.log(id)
    const ShopCart = await this.app.model.ShopCart.destroy({where:{id:id}})
  return { ShopCart };
}
async update(body) {
  console.log(body)
  const id = body.id
  const ShopCart = await this.app.model.ShopCart.update(body,{where:{id:id}})
return { ShopCart };
}
async info(query) {
  console.log(query)
  const ShopCart = await this.app.model.ShopCart.findAll({include:[{model:this.app.model.User},{model:this.app.model.ProductSku,include:[{model:this.app.model.Category},{model:this.app.model.Brand},{model:this.app.model.ProductSpu}]}],where:query})
return { ShopCart };
}
async findByPage(query) {
  console.log(query)
  const size = query.size
  const page = query.page
  const name = query.name
  const Op = Sequelize.Op
  let nameFilter = name ? { name: { [Op.like]: '%'+name+'%'}} : {}
  console.log(nameFilter)
  const ShopCart = await this.app.model.ShopCart.findAll({include:[{model:this.app.model.Category},{model:this.app.model.Brand}],where:nameFilter,limit:parseInt(size),offset:size * (page - 1),})
return { ShopCart };
}
}
module.exports = ShopCartService;