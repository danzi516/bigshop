'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller } = app;
  // category-router
  router.get('/category/add', controller.category.add);
  router.get('/category/delete', controller.category.delete);
  router.get('/category/update', controller.category.update);
  router.get('/category/info', controller.category.info);
  router.get('/category/findByTree', controller.category.findByTree);
  router.get('/category/findByPage', controller.category.findByPage);
  // brand-router
  router.get('/brand/add', controller.brand.add);
  router.get('/brand/delete', controller.brand.delete);
  router.get('/brand/update', controller.brand.update);
  router.get('/brand/info', controller.brand.info);
  router.get('/brand/findByPage', controller.brand.findByPage);
  router.get('/brand/groupByPyf', controller.brand.groupByPyf);
  // brandCategory-router
  router.get('/brandCategory/add', controller.brandCategory.add);
  router.get('/brandCategory/delete', controller.brandCategory.delete);
  router.get('/brandCategory/update', controller.brandCategory.update);
  router.get('/brandCategory/info', controller.brandCategory.info);
  // spu-router
  router.get('/productSpu/add', controller.productSpu.add);
  router.get('/productSpu/delete', controller.productSpu.delete);
  router.get('/productSpu/update', controller.productSpu.update);
  router.get('/productSpu/info', controller.productSpu.info);
  // sku-router
  router.get('/productSku/add', controller.productSku.add);
  router.get('/productSku/delete', controller.productSku.delete);
  router.get('/productSku/update', controller.productSku.update);
  router.get('/productSku/info', controller.productSku.info);
  router.get('/productSku/findByPage', controller.productSku.findByPage);
  // attrBase-router
  router.get('/productAttrBase/add', controller.productAttrBase.add);
  router.get('/productAttrBase/delete', controller.productAttrBase.delete);
  router.get('/productAttrBase/update', controller.productAttrBase.update);
  router.get('/productAttrBase/info', controller.productAttrBase.info);
  // attr-router
  router.get('/productAttrSale/add', controller.productAttrSale.add);
  router.get('/productAttrSale/delete', controller.productAttrSale.delete);
  router.get('/productAttrSale/update', controller.productAttrSale.update);
  router.get('/productAttrSale/info', controller.productAttrSale.info);
  // attrValue-router
  router.get('/productAttrSaleValue/add', controller.productAttrSaleValue.add);
  router.get('/productAttrSaleValue/delete', controller.productAttrSaleValue.delete);
  router.get('/productAttrSaleValue/update', controller.productAttrSaleValue.update);
  router.get('/productAttrSaleValue/info', controller.productAttrSaleValue.info);
  // SpuSkuAttrMap-router
  router.get('/productSpuSkuAttrMap/add', controller.productSpuSkuAttrMap.add);
  router.get('/productSpuSkuAttrMap/delete', controller.productSpuSkuAttrMap.delete);
  router.get('/productSpuSkuAttrMap/update', controller.productSpuSkuAttrMap.update);
  router.get('/productSpuSkuAttrMap/info', controller.productSpuSkuAttrMap.info);
  // shopCart-router
  router.get('/shopCart/add', controller.shopCart.add);
  router.get('/shopCart/delete', controller.shopCart.delete);
  router.get('/shopCart/update', controller.shopCart.update);
  router.get('/shopCart/info', controller.shopCart.info);
  // User-router
  router.get('/user/add', controller.user.add);
  router.get('/user/delete', controller.user.delete);
  router.get('/user/update', controller.user.update);
  router.get('/user/info', controller.user.info);
  // SkuExt-router
  router.get('/productSkuExt/add', controller.productSkuExt.add);
  router.get('/productSkuExt/delete', controller.productSkuExt.delete);
  router.get('/productSkuExt/update', controller.productSkuExt.update);
  router.get('/productSkuExt/info', controller.productSkuExt.info);
  // organCustomer-router
  router.get('/organCustomer/infoByPage', controller.organCustomer.infoByPage);
  router.get('/organCustomer/add', controller.productSkuExt.add);
  router.get('/organCustomer/delete', controller.productSkuExt.delete);
  router.get('/organCustomer/update', controller.productSkuExt.update);
  router.get('/organCustomer/info', controller.productSkuExt.info);
  // printShop-router
  router.get('/printShop/getInit', controller.printShop.getInit);
  router.get('/printShop/getCustomer', controller.printShop.getCustomer);
  router.get('/printShop/login', controller.printShop.login);
  router.get('/printShop/getSku', controller.printShop.getSku);
  router.get('/printShop/getPrintCategory', controller.printShop.getPrintCategory);

  // organ-router
  router.get('/organ/add', controller.organ.add);
  router.get('/organ/delete', controller.organ.delete);
  router.get('/organ/update', controller.organ.update);
  router.get('/organ/info', controller.organ.info);
  router.get('/organ/infoByPage', controller.organ.infoByPage);

  // organMember-router
  router.get('/organMember/add', controller.organMember.add);
  router.get('/organMember/delete', controller.organMember.delete);
  router.get('/organMember/update', controller.organMember.update);
  router.get('/organMember/info', controller.organMember.info);
  router.get('/organMember/infoByPage', controller.organMember.infoByPage);
  
  // area-router
  router.get('/area/getProviceList', controller.area.getProviceList);
  router.get('/area/getCityList', controller.area.getCityList);
  router.get('/area/getAreaList', controller.area.getAreaList);

  // union-router
  router.get('/union/add', controller.union.add);
  router.get('/union/delete', controller.union.delete);
  router.get('/union/update', controller.union.update);
  router.get('/union/info', controller.union.info);
  router.get('/union/infoByPage', controller.union.infoByPage);

  //upload
  router.post('/upload/upload', controller.upload.upload);
};
